<ul class="asAdvantagesList">
	<li class="asAdvantagesList__item">
		<figure>
			<img src="img/Garant.png" alt="Гарантия 10 лет">
			<figcaption>Гарантия 10 лет</figcaption>
		</figure>
	</li>
	<li class="asAdvantagesList__item">
		<figure>
			<img src="img/Measure.png" alt="Профессиональный замер">
			<figcaption>Профессиональный замер</figcaption>
		</figure>
	</li>
	<li class="asAdvantagesList__item">
		<figure>
			<img src="img/gu.png" alt="Фунитура G-U (Австрия)">
			<figcaption>Фунитура G-U (Австрия)</figcaption>
		</figure>
	</li>
	<li class="asAdvantagesList__item">
		<figure>
			<img src="img/Progress.png" alt="Многолетний опыт, производим окна с 1998 года">
			<figcaption>Многолетний опыт, производим окна с 1998 года</figcaption>
		</figure>
	</li>
	<li class="asAdvantagesList__item">
		<figure>
			<img src="img/Clean.png" alt="Демонтаж и уборка мусора">
			<figcaption>Демонтаж и уборка мусора</figcaption>
		</figure>
	</li>
	<li class="asAdvantagesList__item">
		<figure>
			<img src="img/guardian.png" alt="Стекла Guardian (Англия)">
			<figcaption>Стекла Guardian (Англия)</figcaption>
		</figure>
	</li>
	<li class="asAdvantagesList__item">
		<figure>
			<img src="img/GEO.png" alt="Более 120 точек продаж, самая большая сеть магазинов">
			<figcaption>Более 120 точек продаж, самая большая сеть магазинов</figcaption>
		</figure>
	</li>
	<li class="asAdvantagesList__item">
		<figure>
			<img src="img/Credit_03.png" alt="Кредит и рассрочка">
			<figcaption>Кредит и рассрочка</figcaption>
		</figure>
	</li>
	<li class="asAdvantagesList__item">
		<figure>
			<img src="img/ECO.png" alt="Энергосберегающий монтаж по ГОСТУ">
			<figcaption>Энергосберегающий монтаж по ГОСТУ</figcaption>
		</figure>
	</li>
	<li class="asAdvantagesList__item">
		<figure>
			<img src="img/Repair.png" alt="Бесплатное обслуживание на протяжении 10 лет (регулировка, ремонт)">
			<figcaption>Бесплатное обслуживание на протяжении 10 лет (регулировка, ремонт)</figcaption>
		</figure>
	</li>
	<li class="asAdvantagesList__item">
		<figure>
			<img src="img/Delivered.png" alt="Доставка по Украине">
			<figcaption>Доставка по Украине</figcaption>
		</figure>
	</li>
	<li class="asAdvantagesList__item">
		<figure>
			<img src="img/PArts_02.png" alt="Оплата частями">
			<figcaption>Оплата частями</figcaption>
		</figure>
	</li>
</ul>