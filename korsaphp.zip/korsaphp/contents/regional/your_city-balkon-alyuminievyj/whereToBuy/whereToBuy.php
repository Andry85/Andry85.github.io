<section class="aspreambule">
	<?php include 'whereToBuy__title.php'; ?>
	<div class="aspreambule__inner">
		<div class="row">
			<div class="col-md-5">
				<?php include 'contents/whereToBuy/whereToBuy__content.php'; ?>
			</div>
			<div class="col-md-7">
				<?php include 'contents/whereToBuy/whereToBuy__offices.php'; ?>
			</div>
		</div>
	</div>
</section>