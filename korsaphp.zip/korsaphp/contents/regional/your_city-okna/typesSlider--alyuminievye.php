<div class="listType_1">

	<div class="listType_1__item">
		<figure class="listType_1__pic">
			<div class="listType_1__img">
				<img src="uploads/your_city-okna/types/001.png" alt="">
			</div>
			<figcaption class="listType_1__title">Одностворчатое окно с открывающайся створкой</figcaption>
		</figure>
		<div class="listType_1__footer">
			<div class="asPrice">
				Цена от
				<span class="asPrice__count">1150</span>
				<span class="asPrice__currency">грн</span>
			</div>
			<a class="js-callModal asBtnLink asBtnLink--primary" href="#" title="ЗАЯВКА НА ПОКУПКУ ОКНА">Заказать</a>
		</div>
	</div>

	<div class="listType_1__item">
		<figure class="listType_1__pic">
			<div class="listType_1__img">
				<img src="uploads/your_city-okna/types/002.png" alt="">
			</div>
			<figcaption class="listType_1__title">Двустворчатое окно с открывающайся створкой</figcaption>
		</figure>
		<div class="listType_1__footer">
			<div class="asPrice">
				Цена от
				<span class="asPrice__count">2150</span>
				<span class="asPrice__currency">грн</span>
			</div>
			<a class="js-callModal asBtnLink asBtnLink--primary" href="#" title="ЗАЯВКА НА ПОКУПКУ ОКНА">Заказать</a>
		</div>
	</div>

	<div class="listType_1__item">	
		<figure class="listType_1__pic">
			<div class="listType_1__img">
				<img src="uploads/your_city-okna/types/003.png" alt="">
			</div>
			<figcaption class="listType_1__title">Окно из трех частей с открывающайся центральной створкой</figcaption>
		</figure>
		<div class="listType_1__footer">
			<div class="asPrice">
				Цена от
				<span class="asPrice__count">3150</span>
				<span class="asPrice__currency">грн</span>
			</div>
			<a class="js-callModal asBtnLink asBtnLink--primary" href="#" title="ЗАЯВКА НА ПОКУПКУ ОКНА">Заказать</a>
		</div>
	</div>

	<div class="listType_1__item">
		<figure class="listType_1__pic">
			<div class="listType_1__img">
				<img src="uploads/your_city-okna/types/004.png" alt="">
			</div>
			<figcaption class="listType_1__title">Панорамное окно от пола до потолка</figcaption>
		</figure>
		<div class="listType_1__footer">
			<div class="asPrice">
				Цена от
				<span class="asPrice__count">3570</span>
				<span class="asPrice__currency">грн</span>
			</div>
			<a class="js-callModal asBtnLink asBtnLink--primary" href="#" title="ЗАЯВКА НА ПОКУПКУ ОКНА">Заказать</a>
		</div>
	</div>


</div>