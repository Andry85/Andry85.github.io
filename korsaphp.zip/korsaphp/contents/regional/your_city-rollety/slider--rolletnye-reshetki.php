<div class="asCarousel">
	<div class="owl-carousel">
		<div class="asCarousel__item">
			<a href="uploads/your_city-rolletnye-reshetki/portfolio/001.jpg" data-fancybox="plascicImages-2">
				<img src="uploads/your_city-rolletnye-reshetki/portfolio/001.jpg" alt="">
			</a>	
			<a href="uploads/your_city-rolletnye-reshetki/portfolio/002.jpg" data-fancybox="plascicImages-2">
				<img src="uploads/your_city-rolletnye-reshetki/portfolio/002.jpg" alt="">
			</a>
		</div>
		<div class="asCarousel__item">	
			<a href="uploads/your_city-rolletnye-reshetki/portfolio/003.jpg" data-fancybox="plascicImages-2">
				<img src="uploads/your_city-rolletnye-reshetki/portfolio/003.jpg" alt="">
			</a>	
			<a href="uploads/your_city-rolletnye-reshetki/portfolio/004.jpg" data-fancybox="plascicImages-2">
				<img src="uploads/your_city-rolletnye-reshetki/portfolio/004.jpg" alt="">
			</a>
		</div>
		<div class="asCarousel__item">
			<a href="uploads/your_city-rolletnye-reshetki/portfolio/005.jpg" data-fancybox="plascicImages-2">
				<img src="uploads/your_city-rolletnye-reshetki/portfolio/005.jpg" alt="">
			</a>	
			<a href="uploads/your_city-rolletnye-reshetki/portfolio/006.jpg" data-fancybox="plascicImages-2">
				<img src="uploads/your_city-rolletnye-reshetki/portfolio/006.jpg" alt="">
			</a>
		</div>
		<div class="asCarousel__item">	
			<a href="uploads/your_city-rolletnye-reshetki/portfolio/007.jpg" data-fancybox="plascicImages-2">
				<img src="uploads/your_city-rolletnye-reshetki/portfolio/007.jpg" alt="">
			</a>	
			<a href="uploads/your_city-rolletnye-reshetki/portfolio/008.jpg" data-fancybox="plascicImages-2">
				<img src="uploads/your_city-rolletnye-reshetki/portfolio/008.jpg" alt="">
			</a>
		</div>
		
	</div>
</div>