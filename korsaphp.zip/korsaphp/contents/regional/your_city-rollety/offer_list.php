<div class="offerListWrap offerListWrap--shutters">
	<h2 class="offerListWrap__title">Мы предлагаем</h2>
	<p class="offerListWrap__desc">ТМ КОРСА производит защитные роллеты для окон и дверей, а также роллетные решетки.</p>
	<ul class="offerList">
		<li class="offerList__item">
			<a href="#shutters_type_0">
				<h3 class="offerList__title">Защитные роллеты</h3>
				<figure class="offerList__pic">
					<img src="uploads/your_city-rollety/offer_pic-1.jpg" alt="">
				</figure>
				<p class="offerList__text">Ручное или автоматическое управление. Дополнительная защита Ваших окон, разные цвета, другие возможности</p>
			</a>
		</li>
		<li class="offerList__item">
			<a href="#shutters_type_1">
				<h3 class="offerList__title">Роллетные решетки</h3>
				<figure class="offerList__pic">
					<img src="uploads/your_city-rollety/offer_pic-2.jpg" alt="">
				</figure>
				<p class="offerList__text">Полупрозрачные роллеты для торговых центров, кафе, офисов. Большие размеры, жесткая конструкция</p>
			</a>
		</li>
	</ul>
</div>