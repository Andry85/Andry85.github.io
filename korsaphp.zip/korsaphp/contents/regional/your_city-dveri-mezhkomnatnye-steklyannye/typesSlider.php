<div class="listType_1">

	<div class="listType_1__item">
		<a class="listType_1__link" href="#" title="">
			<figure class="listType_1__pic">
				<div class="listType_1__img">
					<img src="uploads/your_city-dveri-mezhkomnatnye-steklyannye/door_1.jpg" alt="">
				</div>
				<figcaption>Цельностеклянная дверь межкомнатная</figcaption>
			</figure>
		</a>
		<div class="listType_1__footer">
			<div class="asPrice">
				Цена от
				<span class="asPrice__count">11021</span>
				<span class="asPrice__currency">грн</span>
			</div>
			<a class="js-callModal asBtnLink asBtnLink--primary" href="#" title="ЗАЯВКА НА ПОКУПКУ ДВЕРЕЙ">Заказать</a>
		</div>
	</div>

	<div class="listType_1__item">
		<a class="listType_1__link" href="#" title="">
			<figure class="listType_1__pic">
				<div class="listType_1__img">
					<img src="uploads/your_city-dveri-mezhkomnatnye-steklyannye/door_2.jpg" alt="">
				</div>
				<figcaption>Маятниковая цельностеклянная дверь</figcaption>
			</figure>
		</a>
		<div class="listType_1__footer">
			<div class="asPrice">
				Цена от
				<span class="asPrice__count">16840</span>
				<span class="asPrice__currency">грн</span>
			</div>
			<a class="js-callModal asBtnLink asBtnLink--primary" href="#" title="ЗАЯВКА НА ПОКУПКУ ДВЕРЕЙ">Заказать</a>
		</div>
	</div>

	<div class="listType_1__item">
		<a class="listType_1__link" href="#" title="">
			<figure class="listType_1__pic">
				<div class="listType_1__img">
					<img src="uploads/your_city-dveri-mezhkomnatnye-steklyannye/door_3.jpg" alt="">
				</div>
				<figcaption>Штульповая цельностеклянная дверь</figcaption>
			</figure>
		</a>
		<div class="listType_1__footer">
			<div class="asPrice">
				Цена от
				<span class="asPrice__count">17440</span>
				<span class="asPrice__currency">грн</span>
			</div>
			<a class="js-callModal asBtnLink asBtnLink--primary" href="#" title="ЗАЯВКА НА ПОКУПКУ ДВЕРЕЙ">Заказать</a>
		</div>
	</div>

	<div class="listType_1__item">
		<a class="listType_1__link" href="#" title="">
			<figure class="listType_1__pic">
				<div class="listType_1__img">
					<img src="uploads/your_city-dveri-mezhkomnatnye-steklyannye/door_5.jpg" alt="">
				</div>	
				<figcaption>Раздвижные двери двустворчатые</figcaption>
			</figure>
		</a>
		<div class="listType_1__footer">
			<div class="asPrice">
				Цена от
				<span class="asPrice__count">16365</span>
				<span class="asPrice__currency">грн</span>
			</div>
			<a class="js-callModal asBtnLink asBtnLink--primary" href="#" title="ЗАЯВКА НА ПОКУПКУ ДВЕРЕЙ">Заказать</a>
		</div>	
	</div>

	<div class="listType_1__item">
		<a class="listType_1__link" href="#" title="">
			<figure class="listType_1__pic">
				<div class="listType_1__img">
					<img src="uploads/your_city-dveri-mezhkomnatnye-steklyannye/door_6.jpg" alt="">
				</div>	
				<figcaption>Раздвижные стеклянные двери KORSA TIARA</figcaption>
			</figure>
		</a>
		<div class="listType_1__footer">
			<div class="asPrice">
				Цена от
				<span class="asPrice__count">28100</span>
				<span class="asPrice__currency">грн</span>
			</div>
			<a class="js-callModal asBtnLink asBtnLink--primary" href="#" title="ЗАЯВКА НА ПОКУПКУ ДВЕРЕЙ">Заказать</a>
		</div>	
	</div>

	<div class="listType_1__item">
		<a class="listType_1__link" href="#" title="">
			<figure class="listType_1__pic">
				<div class="listType_1__img">
					<img src="uploads/your_city-dveri-mezhkomnatnye-steklyannye/door_7.jpg" alt="">
				</div>	
				<figcaption>Раздвижные стеклянные двери KORSA PARALLEL</figcaption>
			</figure>
		</a>
		<div class="listType_1__footer">
			<div class="asPrice">
				Цена от
				<span class="asPrice__count">18050</span>
				<span class="asPrice__currency">грн</span>
			</div>
			<a class="js-callModal asBtnLink asBtnLink--primary" href="#" title="ЗАЯВКА НА ПОКУПКУ ДВЕРЕЙ">Заказать</a>
		</div>	
	</div>

	<div class="listType_1__item">
		<a class="listType_1__link" href="#" title="">
			<figure class="listType_1__pic">
				<div class="listType_1__img">
					<img src="uploads/your_city-dveri-mezhkomnatnye-steklyannye/door_8.jpg" alt="">
				</div>	
				<figcaption>Раздвижные стеклянные двери KORSA ACCORDEON</figcaption>
			</figure>
		</a>
		<div class="listType_1__footer">
			<div class="asPrice">
				Цена от
				<span class="asPrice__count">61590</span>
				<span class="asPrice__currency">грн</span>
			</div>
			<a class="js-callModal asBtnLink asBtnLink--primary" href="#" title="ЗАЯВКА НА ПОКУПКУ ДВЕРЕЙ">Заказать</a>
		</div>	
	</div>

	<div class="listType_1__item">
		<a class="listType_1__link" href="#" title="">
			<figure class="listType_1__pic">
				<div class="listType_1__img">
					<img src="uploads/your_city-dveri-mezhkomnatnye-steklyannye/door_9.jpg" alt="">
				</div>	
				<figcaption>Раздвижные стеклянные двери KORSA GLASSHARMONY</figcaption>
			</figure>
		</a>
		<div class="listType_1__footer">
			<div class="asPrice">
				Цена от
				<span class="asPrice__count">66985</span>
				<span class="asPrice__currency">грн</span>
			</div>
			<a class="js-callModal asBtnLink asBtnLink--primary" href="#" title="ЗАЯВКА НА ПОКУПКУ ДВЕРЕЙ">Заказать</a>
		</div>	
	</div>

</div>