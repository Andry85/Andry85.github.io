<div class="discountWrap">

	<div class="container">
		<div class="row">
			<div class="col-md-3">
				
				<div class="discountBox">
					<div class="discountBox__label"><span>акция</span></div>
					<div class="discountBox__inner">
						<span class="discountBox__bg"></span>
						<div class="discountBox__title">
							<span>скидка</span>
							<img src="./img/discount_firm_icon.png" alt="">
						</div>
						<div class="discountBox__procent">-30<sup>%</sup></div>
					</div>
				</div>

			</div>
			<div class="col-md-6">
				<div class="discountInner">
					<div class="discountInner__message">Покупайте выгодно!</div>
					<h2 class="discountInner__title">Остекление лоджии пластиковыми окнами REHAU <strong>СО СКИДКОЙ 30%</strong></h2>
					<p class="discountInner__text"><span>ТОРОПИТЕСЬ!</span> АКЦИЯ ТОЛЬКО <i>ДО КОНЦА НЕДЕЛИ</i></p>
				</div>
			</div>
			<div class="col-md-3">
				<div class="discountBox discountBox--right">
					<div class="discountBox__label"><span>акция</span></div>
					<div class="discountBox__inner">
						<span class="discountBox__bg"></span>
						<div class="discountBox__title">
							<span>скидка</span>
							<img src="./img/discount_firm_icon.png" alt="">
						</div>
						<div class="discountBox__procent">-30<sup>%</sup></div>
					</div>
				</div>
			</div>
		</div>
	</div>	

</div>