<section class="asGoods asGoods--withoutTopLine">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<h2 class="asGoods__title asGoods__title--examples">Примеры наших работ</h2>
				<!-- Slider Start -->
					<div class="asCarousel--big">
						<div class="owl-carousel">
							<div class="asCarousel--big__item">
								<a href="uploads/your_city-peregorodki-plastikovye/001.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-peregorodki-plastikovye/001.jpg" alt="">
								</a>
								<a href="uploads/your_city-peregorodki-plastikovye/002.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-peregorodki-plastikovye/002.jpg" alt="">
								</a>
								<a href="uploads/your_city-peregorodki-plastikovye/003.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-peregorodki-plastikovye/003.jpg" alt="">
								</a>
								<a href="uploads/your_city-peregorodki-plastikovye/004.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-peregorodki-plastikovye/004.jpg" alt="">
								</a>
							</div>
							<div class="asCarousel--big__item">
								<a href="uploads/your_city-peregorodki-plastikovye/005.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-peregorodki-plastikovye/005.jpg" alt="">
								</a>
								<a href="uploads/your_city-peregorodki-plastikovye/006.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-peregorodki-plastikovye/006.jpg" alt="">
								</a>
								<a href="uploads/your_city-peregorodki-plastikovye/007.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-peregorodki-plastikovye/007.jpg" alt="">
								</a>
								<a href="uploads/your_city-peregorodki-plastikovye/008.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-peregorodki-plastikovye/008.jpg" alt="">
								</a>
							</div>
							<div class="asCarousel--big__item">
								<a href="uploads/your_city-peregorodki-plastikovye/009.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-peregorodki-plastikovye/009.jpg" alt="">
								</a>
								<a href="uploads/your_city-peregorodki-plastikovye/010.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-peregorodki-plastikovye/010.jpg" alt="">
								</a>
								<a href="uploads/your_city-peregorodki-plastikovye/011.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-peregorodki-plastikovye/011.jpg" alt="">
								</a>
								<a href="uploads/your_city-peregorodki-plastikovye/012.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-peregorodki-plastikovye/012.jpg" alt="">
								</a>
							</div>
							<div class="asCarousel--big__item">
								<a href="uploads/your_city-peregorodki-plastikovye/013.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-peregorodki-plastikovye/013.jpg" alt="">
								</a>
								<a href="uploads/your_city-peregorodki-plastikovye/014.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-peregorodki-plastikovye/014.jpg" alt="">
								</a>
								<a href="uploads/your_city-peregorodki-plastikovye/015.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-peregorodki-plastikovye/015.jpg" alt="">
								</a>
								<a href="uploads/your_city-peregorodki-plastikovye/016.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-peregorodki-plastikovye/016.jpg" alt="">
								</a>
							</div>
						</div>
					</div>
				<!-- Slider End -->
					
			</div>
		</div>
	</div>
</section>