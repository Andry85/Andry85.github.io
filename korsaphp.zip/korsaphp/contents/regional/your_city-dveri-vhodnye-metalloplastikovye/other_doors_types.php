<section class="asGoods">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<h2 class="asGoods__title asGoods__title--types">Другие типы входных дверей</h2>
				<ul class="listType_3">
					<li class="listType_3__item">
						<a class="listType_3__link" href="#" title="">
							<figure class="listType_3__pic">
								<div class="listType_3__img">
									<img src="img/aluminum_plastic_doors.jpg" alt="">
								</div>
								<figcaption>Алюминиевые двери входные</figcaption>
							</figure>
						</a>
					</li>
					<li class="listType_3__item">
						<a class="listType_3__link" href="#" title="">
							<figure class="listType_3__pic">
								<div class="listType_3__img">
									<img src="img/aluminum_metal_doors.jpg" alt="">
								</div>
								<figcaption>Металлические двери входные</figcaption>
							</figure>
						</a>
					</li>
				</ul>
			</div>
		</div>
	</div>
</section>
