<div class="listType_1">

	<div class="listType_1__item">
		<div class="listType_1__item__info">
			<div class="listType_1__item__discount">
	            <p>Экономия</p>
	            <h5>3073 грн</h5>
	        </div>
	        <span class="listType_1__item__pay"></span>
	    </div>
		<figure class="listType_1__pic">
			<div class="listType_1__img">
				<img src="uploads/your_city-dveri-mezhkomnatnye-alyuminievye/catalog/001.jpg" alt="">
			</div>
		</figure>
		<div class="listType_1__footer">
			<p class="asPrice_withoutDiscount">Цена без скидки от <span class="line-through">10243 грн</span></p>
			<div class="asPrice">
				Цена от
				<span class="asPrice__count">7170</span>
				<span class="asPrice__currency">грн</span>
			</div>
			<a class="js-callModal asBtnLink asBtnLink--primary" href="#" title="ЗАЯВКА НА ПОКУПКУ ДВЕРЕЙ">Заказать</a>
		</div>
	</div>

	<div class="listType_1__item">
		<div class="listType_1__item__info">
			<div class="listType_1__item__discount">
	            <p>Экономия</p>
	            <h5>4062 грн</h5>
	        </div>
	        <span class="listType_1__item__pay"></span>
	    </div>
		<figure class="listType_1__pic">
			<div class="listType_1__img">
				<img src="uploads/your_city-dveri-mezhkomnatnye-alyuminievye/catalog/002.jpg" alt="">
			</div>
		</figure>
		<div class="listType_1__footer">
			<p class="asPrice_withoutDiscount">Цена без скидки от <span class="line-through">13541 грн</span></p>
			<div class="asPrice">
				Цена от
				<span class="asPrice__count">9479</span>
				<span class="asPrice__currency">грн</span>
			</div>
			<a class="js-callModal asBtnLink asBtnLink--primary" href="#" title="ЗАЯВКА НА ПОКУПКУ ДВЕРЕЙ">Заказать</a>
		</div>
	</div>

	<div class="listType_1__item">
		<div class="listType_1__item__info">
			<div class="listType_1__item__discount">
	            <p>Экономия</p>
	            <h5>5082 грн</h5>
	        </div>
	        <span class="listType_1__item__pay"></span>
	    </div>
		<figure class="listType_1__pic">
			<div class="listType_1__img">
				<img src="uploads/your_city-dveri-mezhkomnatnye-alyuminievye/catalog/003.jpg" alt="">
			</div>
		</figure>
		<div class="listType_1__footer">
			<p class="asPrice_withoutDiscount">Цена без скидки от <span class="line-through">16941 грн</span></p>
			<div class="asPrice">
				Цена от
				<span class="asPrice__count">11859</span>
				<span class="asPrice__currency">грн</span>
			</div>
			<a class="js-callModal asBtnLink asBtnLink--primary" href="#" title="ЗАЯВКА НА ПОКУПКУ ДВЕРЕЙ">Заказать</a>
		</div>
	</div>

	<div class="listType_1__item">
		<div class="listType_1__item__info">
			<div class="listType_1__item__discount">
	            <p>Экономия</p>
	            <h5>4236 грн</h5>
	        </div>
	        <span class="listType_1__item__pay"></span>
	    </div>
		<figure class="listType_1__pic">
			<div class="listType_1__img">
				<img src="uploads/your_city-dveri-mezhkomnatnye-alyuminievye/catalog/004.jpg" alt="">
			</div>
		</figure>
		<div class="listType_1__footer">
			<p class="asPrice_withoutDiscount">Цена без скидки от <span class="line-through">14120 грн</span></p>
			<div class="asPrice">
				Цена от
				<span class="asPrice__count">9884</span>
				<span class="asPrice__currency">грн</span>
			</div>
			<a class="js-callModal asBtnLink asBtnLink--primary" href="#" title="ЗАЯВКА НА ПОКУПКУ ДВЕРЕЙ">Заказать</a>
		</div>
	</div>

	<div class="listType_1__item">
		<div class="listType_1__item__info">
			<div class="listType_1__item__discount">
	            <p>Экономия</p>
	            <h5>3238 грн</h5>
	        </div>
	        <span class="listType_1__item__pay"></span>
	    </div>
		<figure class="listType_1__pic">
			<div class="listType_1__img">
				<img src="uploads/your_city-dveri-mezhkomnatnye-alyuminievye/catalog/005.jpg" alt="">
			</div>
		</figure>
		<div class="listType_1__footer">
			<p class="asPrice_withoutDiscount">Цена без скидки от <span class="line-through">10792 грн</span></p>
			<div class="asPrice">
				Цена от
				<span class="asPrice__count">7554</span>
				<span class="asPrice__currency">грн</span>
			</div>
			<a class="js-callModal asBtnLink asBtnLink--primary" href="#" title="ЗАЯВКА НА ПОКУПКУ ДВЕРЕЙ">Заказать</a>
		</div>
	</div>

	<div class="listType_1__item">
		<div class="listType_1__item__info">
			<div class="listType_1__item__discount">
	            <p>Экономия</p>
	            <h5>4313 грн</h5>
	        </div>
	        <span class="listType_1__item__pay"></span>
	    </div>
		<figure class="listType_1__pic">
			<div class="listType_1__img">
				<img src="uploads/your_city-dveri-mezhkomnatnye-alyuminievye/catalog/006.jpg" alt="">
			</div>
		</figure>
		<div class="listType_1__footer">
			<p class="asPrice_withoutDiscount">Цена без скидки от <span class="line-through">14377 грн</span></p>
			<div class="asPrice">
				Цена от
				<span class="asPrice__count">10064</span>
				<span class="asPrice__currency">грн</span>
			</div>
			<a class="js-callModal asBtnLink asBtnLink--primary" href="#" title="ЗАЯВКА НА ПОКУПКУ ДВЕРЕЙ">Заказать</a>
		</div>
	</div>

	<div class="listType_1__item">
		<div class="listType_1__item__info">
			<div class="listType_1__item__discount">
	            <p>Экономия</p>
	            <h5>5377 грн</h5>
	        </div>
	        <span class="listType_1__item__pay"></span>
	    </div>
		<figure class="listType_1__pic">
			<div class="listType_1__img">
				<img src="uploads/your_city-dveri-mezhkomnatnye-alyuminievye/catalog/007.jpg" alt="">
			</div>
		</figure>
		<div class="listType_1__footer">
			<p class="asPrice_withoutDiscount">Цена без скидки от <span class="line-through">17923 грн</span></p>
			<div class="asPrice">
				Цена от
				<span class="asPrice__count">12546</span>
				<span class="asPrice__currency">грн</span>
			</div>
			<a class="js-callModal asBtnLink asBtnLink--primary" href="#" title="ЗАЯВКА НА ПОКУПКУ ДВЕРЕЙ">Заказать</a>
		</div>
	</div>

	<div class="listType_1__item">
		<div class="listType_1__item__info">
			<div class="listType_1__item__discount">
	            <p>Экономия</p>
	            <h5>4530 грн</h5>
	        </div>
	        <span class="listType_1__item__pay"></span>
	    </div>
		<figure class="listType_1__pic">
			<div class="listType_1__img">
				<img src="uploads/your_city-dveri-mezhkomnatnye-alyuminievye/catalog/008.jpg" alt="">
			</div>
		</figure>
		<div class="listType_1__footer">
			<p class="asPrice_withoutDiscount">Цена без скидки от <span class="line-through">15099 грн</span></p>
			<div class="asPrice">
				Цена от
				<span class="asPrice__count">10569</span>
				<span class="asPrice__currency">грн</span>
			</div>
			<a class="js-callModal asBtnLink asBtnLink--primary" href="#" title="ЗАЯВКА НА ПОКУПКУ ДВЕРЕЙ">Заказать</a>
		</div>
	</div>

	<div class="listType_1__item">
		<div class="listType_1__item__info">
			<div class="listType_1__item__discount">
	            <p>Экономия</p>
	            <h5>3200 грн</h5>
	        </div>
	        <span class="listType_1__item__pay"></span>
	    </div>
		<figure class="listType_1__pic">
			<div class="listType_1__img">
				<img src="uploads/your_city-dveri-mezhkomnatnye-alyuminievye/catalog/009.jpg" alt="">
			</div>
		</figure>
		<div class="listType_1__footer">
			<p class="asPrice_withoutDiscount">Цена без скидки от <span class="line-through">10667 грн</span></p>
			<div class="asPrice">
				Цена от
				<span class="asPrice__count">7467</span>
				<span class="asPrice__currency">грн</span>
			</div>
			<a class="js-callModal asBtnLink asBtnLink--primary" href="#" title="ЗАЯВКА НА ПОКУПКУ ДВЕРЕЙ">Заказать</a>
		</div>
	</div>

	<div class="listType_1__item">
		<div class="listType_1__item__info">
			<div class="listType_1__item__discount">
	            <p>Экономия</p>
	            <h5>4249 грн</h5>
	        </div>
	        <span class="listType_1__item__pay"></span>
	    </div>
		<figure class="listType_1__pic">
			<div class="listType_1__img">
				<img src="uploads/your_city-dveri-mezhkomnatnye-alyuminievye/catalog/010.jpg" alt="">
			</div>
		</figure>
		<div class="listType_1__footer">
			<p class="asPrice_withoutDiscount">Цена без скидки от <span class="line-through">14165 грн</span></p>
			<div class="asPrice">
				Цена от
				<span class="asPrice__count">9916</span>
				<span class="asPrice__currency">грн</span>
			</div>
			<a class="js-callModal asBtnLink asBtnLink--primary" href="#" title="ЗАЯВКА НА ПОКУПКУ ДВЕРЕЙ">Заказать</a>
		</div>
	</div>

	<div class="listType_1__item">
		<div class="listType_1__item__info">
			<div class="listType_1__item__discount">
	            <p>Экономия</p>
	            <h5>5295 грн</h5>
	        </div>
	        <span class="listType_1__item__pay"></span>
	    </div>
		<figure class="listType_1__pic">
			<div class="listType_1__img">
				<img src="uploads/your_city-dveri-mezhkomnatnye-alyuminievye/catalog/011.jpg" alt="">
			</div>
		</figure>
		<div class="listType_1__footer">
			<p class="asPrice_withoutDiscount">Цена без скидки от <span class="line-through">17651 грн</span></p>
			<div class="asPrice">
				Цена от
				<span class="asPrice__count">12356</span>
				<span class="asPrice__currency">грн</span>
			</div>
			<a class="js-callModal asBtnLink asBtnLink--primary" href="#" title="ЗАЯВКА НА ПОКУПКУ ДВЕРЕЙ">Заказать</a>
		</div>
	</div>

	<div class="listType_1__item">
		<div class="listType_1__item__info">
			<div class="listType_1__item__discount">
	            <p>Экономия</p>
	            <h5>4459 грн</h5>
	        </div>
	        <span class="listType_1__item__pay"></span>
	    </div>
		<figure class="listType_1__pic">
			<div class="listType_1__img">
				<img src="uploads/your_city-dveri-mezhkomnatnye-alyuminievye/catalog/012.jpg" alt="">
			</div>
		</figure>
		<div class="listType_1__footer">
			<p class="asPrice_withoutDiscount">Цена без скидки от <span class="line-through">14863 грн</span></p>
			<div class="asPrice">
				Цена от
				<span class="asPrice__count">10404</span>
				<span class="asPrice__currency">грн</span>
			</div>
			<a class="js-callModal asBtnLink asBtnLink--primary" href="#" title="ЗАЯВКА НА ПОКУПКУ ДВЕРЕЙ">Заказать</a>
		</div>
	</div>



	

	

</div>