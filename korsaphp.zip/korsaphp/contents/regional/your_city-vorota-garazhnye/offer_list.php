<div class="offerListWrap">
	<h2 class="offerListWrap__title">Мы предлагаем</h2>
	<p class="offerListWrap__desc">ТМ КОРСА производит офисные перегородки трёх основных типов - конструкции на базе металлопластикового профиля REHAU EURO-Design 60, алюминиевого профиля с разнообразным заполнением и цельностеклянные перегородки из закаленного стекла.</p>
	<ul class="offerList">
		<li class="offerList__item">
			<a href="#voroty_type_0">
				<h3 class="offerList__title">Секционные ворота</h3>
				<figure class="offerList__pic">
					<img src="uploads/your_city-vorota-garazhnye/offers/001.jpg" alt="">
				</figure>
				<p class="offerList__text">Надежные, теплые подъемные ворота. Взломобезопасность, высокое качество, много вариантов</p>
			</a>	
		</li>
		<li class="offerList__item">
			<a href="#voroty_type_1">
				<h3 class="offerList__title">Подъемно - поворотные</h3>
				<figure class="offerList__pic">
					<img src="uploads/your_city-vorota-garazhnye/offers/002.jpg" alt="">
				</figure>
				<p class="offerList__text">Бюджетное решения для гаража. Плоскость ворот поднимается вверх, с поворотом параллельно к земле</p>
			</a>
		</li>
		<li class="offerList__item">
			<a href="#voroty_type_2">
				<h3 class="offerList__title">Роллетные ворота</h3>
				<figure class="offerList__pic">
					<img src="uploads/your_city-vorota-garazhnye/offers/003.jpg" alt="">
				</figure>
				<p class="offerList__text">Простые ворота для холодных складов, гаражей, торговых центров и т.п. Собираются в короб</p>
			</a>
		</li>
		<li class="offerList__item">
			<a href="#voroty_type_3">
				<h3 class="offerList__title">Рулонные ворота</h3>
				<figure class="offerList__pic">
					<img src="uploads/your_city-vorota-garazhnye/offers/004.jpg" alt="">
				</figure>
				<p class="offerList__text">Больше размеры и скорость открытия в сравнении с роллетными воротами. Собираются в короб</p>
			</a>	
		</li>
	</ul>
</div>