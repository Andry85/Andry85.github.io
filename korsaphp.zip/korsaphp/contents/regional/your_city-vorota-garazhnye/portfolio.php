<section class="asGoods asGoods--withoutTopLine">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<h2 class="asGoods__title asGoods__title--examples">Примеры наших работ</h2>
				<!-- Slider Start -->
					<div class="asCarousel--big">
						<div class="owl-carousel">
							<div class="asCarousel--big__item">
								<a href="uploads/your_city-vorota-sekcionnye/portfolio/001.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-vorota-sekcionnye/portfolio/001.jpg" alt="">
								</a>
								<a href="uploads/your_city-vorota-sekcionnye/portfolio/002.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-vorota-sekcionnye/portfolio/002.jpg" alt="">
								</a>
								<a href="uploads/your_city-vorota-sekcionnye/portfolio/003.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-vorota-sekcionnye/portfolio/003.jpg" alt="">
								</a>
								<a href="uploads/your_city-vorota-sekcionnye/portfolio/004.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-vorota-sekcionnye/portfolio/004.jpg" alt="">
								</a>
							</div>
							<div class="asCarousel--big__item">
								<a href="uploads/your_city-vorota-podemno-povorotnye-hormann/portfolio/001.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-vorota-podemno-povorotnye-hormann/portfolio/001.jpg" alt="">
								</a>
								<a href="uploads/your_city-vorota-podemno-povorotnye-hormann/portfolio/002.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-vorota-podemno-povorotnye-hormann/portfolio/002.jpg" alt="">
								</a>
								<a href="uploads/your_city-vorota-podemno-povorotnye-hormann/portfolio/003.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-vorota-podemno-povorotnye-hormann/portfolio/003.jpg" alt="">
								</a>
								<a href="uploads/your_city-vorota-podemno-povorotnye-hormann/portfolio/004.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-vorota-podemno-povorotnye-hormann/portfolio/004.jpg" alt="">
								</a>
							</div>
							<div class="asCarousel--big__item">
								<a href="uploads/your_city-vorota-rolletnye/portfolio/001.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-vorota-rolletnye/portfolio/001.jpg" alt="">
								</a>
								<a href="uploads/your_city-vorota-rolletnye/portfolio/002.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-vorota-rolletnye/portfolio/002.jpg" alt="">
								</a>
								<a href="uploads/your_city-vorota-rolletnye/portfolio/003.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-vorota-rolletnye/portfolio/003.jpg" alt="">
								</a>
								<a href="uploads/your_city-vorota-rolletnye/portfolio/004.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-vorota-rolletnye/portfolio/004.jpg" alt="">
								</a>
							</div>
							<div class="asCarousel--big__item">
								<a href="uploads/your_city-rulonnye-hormann/portfolio/001.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-rulonnye-hormann/portfolio/001.jpg" alt="">
								</a>
								<a href="uploads/your_city-rulonnye-hormann/portfolio/002.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-rulonnye-hormann/portfolio/002.jpg" alt="">
								</a>
								<a href="uploads/your_city-rulonnye-hormann/portfolio/003.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-rulonnye-hormann/portfolio/003.jpg" alt="">
								</a>
								<a href="uploads/your_city-rulonnye-hormann/portfolio/004.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-rulonnye-hormann/portfolio/004.jpg" alt="">
								</a>
							</div>
						</div>
					</div>
				<!-- Slider End -->
					
			</div>
		</div>
	</div>
</section>