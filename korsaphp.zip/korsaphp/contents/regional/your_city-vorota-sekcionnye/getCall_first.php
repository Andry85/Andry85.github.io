<div class="getCallWrap">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<h2 class="getCallWrap__title">поможем подобрать<br> идеальный вариант ворот</h2>
				<p class="getCallWrap__text">Получите бесплатную консультацию по выбору ворот. Мы предложим оптимальный вариант исходя из ваших предпочтений</p>
				<div class="getCallFormWrap">
					<form id="getCallForm_1" method="post" action="#" class="getCallForm">
						<div class="getCallForm__col">
							<input class="getCallForm__field" type="text" name="getcalfirstname__getCallForm_1" placeholder="введите имя" required="required">
						</div>
						<div class="getCallForm__col">
							<input class="getCallForm__field" type="tel" name="getcalphone__getCallForm_1" placeholder="введите телефон" required="required">
						</div>
						<button class="getCallForm__btn">нужна консультация</button>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>	