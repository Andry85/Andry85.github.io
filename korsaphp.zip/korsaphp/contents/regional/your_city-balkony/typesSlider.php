<div class="listType_1">

		<div class="listType_1__item">
			<a class="listType_1__link" href="#" title="">
				<figure class="listType_1__pic">
					<div class="listType_1__img">
						<img src="img/balkony_01.png" alt="">
					</div>
					<figcaption>Окно на балкон, балконная рама</figcaption>
				</figure>
			</a>
			<div class="listType_1__footer">
				<div class="asPrice">
					Цена от
					<span class="asPrice__count">5150</span>
					<span class="asPrice__currency">грн</span>
				</div>
				<a class="js-callModal asBtnLink asBtnLink--primary" href="#" title="ЗАЯВКА НА ПОКУПКУ балкона">Заказать</a>
			</div>
		</div>

		<div class="listType_1__item">
			<a class="listType_1__link" href="#" title="">
				<figure class="listType_1__pic">
					<div class="listType_1__img">
						<img src="img/balkony_02.png" alt="">
					</div>
					<figcaption>Г-образный балкон</figcaption>
				</figure>
			</a>
			<div class="listType_1__footer">
				<div class="asPrice">
					Цена от
					<span class="asPrice__count">5150</span>
					<span class="asPrice__currency">грн</span>
				</div>
				<a class="js-callModal asBtnLink asBtnLink--primary" href="#" title="ЗАЯВКА НА ПОКУПКУ балкона">Заказать</a>
			</div>
		</div>

		<div class="listType_1__item">
			<a class="listType_1__link" href="#" title="">
				<figure class="listType_1__pic">
					<div class="listType_1__img">
						<img src="img/balkony_03.png" alt="">
					</div>
					<figcaption>П-образный балкон</figcaption>
				</figure>
			</a>
			<div class="listType_1__footer">
				<div class="asPrice">
					Цена от
					<span class="asPrice__count">5150</span>
					<span class="asPrice__currency">грн</span>
				</div>
				<a class="js-callModal asBtnLink asBtnLink--primary" href="#" title="ЗАЯВКА НА ПОКУПКУ балкона">Заказать</a>
			</div>
		</div>

		<div class="listType_1__item">
			<a class="listType_1__link" href="#" title="">
				<figure class="listType_1__pic">
					<div class="listType_1__img">
						<img src="img/plastic_window_type_4.png" alt="">
					</div>	
					<figcaption>Балконный блок, дверь и окно</figcaption>
				</figure>
			</a>
			<div class="listType_1__footer">
				<div class="asPrice">
					Цена от
					<span class="asPrice__count">5150</span>
					<span class="asPrice__currency">грн</span>
				</div>
				<a class="js-callModal asBtnLink asBtnLink--primary" href="#" title="ЗАЯВКА НА ПОКУПКУ балкона">Заказать</a>
			</div>	
		</div>
	
</div>