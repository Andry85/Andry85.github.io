<div class="asCarousel">
	<div class="owl-carousel">
		<div class="asCarousel__item">
			<a href="uploads/your_city-peregorodki-steklyannye/001.jpg" data-fancybox="plascicImages-alyuminievye">
				<img src="uploads/your_city-peregorodki-steklyannye/001.jpg" alt="">
			</a>	
			<a href="uploads/your_city-peregorodki-steklyannye/002.jpg" data-fancybox="plascicImages-alyuminievye">
				<img src="uploads/your_city-peregorodki-steklyannye/002.jpg" alt="">
			</a>
		</div>
		<div class="asCarousel__item">
			<a href="uploads/your_city-peregorodki-steklyannye/003.jpg" data-fancybox="plascicImages-alyuminievye">
				<img src="uploads/your_city-peregorodki-steklyannye/003.jpg" alt="">
			</a>	
			<a href="uploads/your_city-peregorodki-steklyannye/004.jpg" data-fancybox="plascicImages-alyuminievye">
				<img src="uploads/your_city-peregorodki-steklyannye/004.jpg" alt="">
			</a>
		</div>
		<div class="asCarousel__item">
			<a href="uploads/your_city-peregorodki-steklyannye/005.jpg" data-fancybox="plascicImages-alyuminievye">
				<img src="uploads/your_city-peregorodki-steklyannye/005.jpg" alt="">
			</a>	
			<a href="uploads/your_city-peregorodki-steklyannye/006.jpg" data-fancybox="plascicImages-alyuminievye">
				<img src="uploads/your_city-peregorodki-steklyannye/006.jpg" alt="">
			</a>
		</div>
		<div class="asCarousel__item">
			<a href="uploads/your_city-peregorodki-steklyannye/007.jpg" data-fancybox="plascicImages-alyuminievye">
				<img src="uploads/your_city-peregorodki-steklyannye/007.jpg" alt="">
			</a>	
			<a href="uploads/your_city-peregorodki-steklyannye/008.jpg" data-fancybox="plascicImages-alyuminievye">
				<img src="uploads/your_city-peregorodki-steklyannye/008.jpg" alt="">
			</a>
		</div>	
	</div>
</div>