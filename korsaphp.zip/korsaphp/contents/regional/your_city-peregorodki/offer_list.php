<div class="offerListWrap">
	<h2 class="offerListWrap__title">Мы предлагаем</h2>
	<p class="offerListWrap__desc">ТМ КОРСА производит офисные перегородки трёх основных типов - конструкции на базе металлопластикового профиля REHAU EURO-Design 60, алюминиевого профиля с разнообразным заполнением и цельностеклянные перегородки из закаленного стекла.</p>
	<ul class="offerList">
		<li class="offerList__item">
			<a href="#peregorodki_type_0">	
				<h3 class="offerList__title">Пластиковые перегородки</h3>
				<figure class="offerList__pic">
					<img src="img/peregorodki_01.jpg" alt="">
				</figure>
				<p class="offerList__text">Эффективное распределение пространства на рабочие зоны и кабинеты. Хорошая шумоизоляция, практичный уход</p>
			</a>	
		</li>
		<li class="offerList__item">
			<a href="#peregorodki_type_1">
				<h3 class="offerList__title">Цельностеклянные перегородки</h3>
				<figure class="offerList__pic">
					<img src="img/peregorodki_02.jpg" alt="">
				</figure>
				<p class="offerList__text">Перегородки из закаленного стекла. Непревзойденный дизайн, отсутствие визуальных ограничений</p>
			</a>
		</li>
		<li class="offerList__item">
			<a href="#peregorodki_type_2">
				<h3 class="offerList__title">перегородки алюминиевые</h3>
				<figure class="offerList__pic">
					<img src="img/peregorodki_03.jpg" alt="">
				</figure>
				<p class="offerList__text">Пространство больших размеров. Современный стиль, долговечность, возможность интеграции с жалюзи</p>
			</a>	
		</li>
	</ul>
</div>