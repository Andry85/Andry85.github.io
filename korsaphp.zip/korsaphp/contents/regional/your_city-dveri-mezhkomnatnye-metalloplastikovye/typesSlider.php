<div class="listType_1">

	<div class="listType_1__item">
		<div class="listType_1__item__info">
			<div class="listType_1__item__discount">
	            <p>Экономия</p>
	            <h5>2643 грн</h5>
	        </div>
	        <span class="listType_1__item__pay"></span>
	    </div>
		<figure class="listType_1__pic">
			<div class="listType_1__img">
				<img src="uploads/your_city-dveri-mezhkomnatnye-metalloplastikovye/catalog/window_1.jpg" alt="">
			</div>
		</figure>
		<div class="listType_1__footer">
			<p class="asPrice_withoutDiscount">Цена без скидки от <span class="line-through">8810 грн</span></p>
			<div class="asPrice">
				Цена от
				<span class="asPrice__count">6167</span>
				<span class="asPrice__currency">грн</span>
			</div>
			<a class="js-callModal asBtnLink asBtnLink--primary" href="#" title="ЗАЯВКА НА ПОКУПКУ ДВЕРЕЙ">Заказать</a>
		</div>
	</div>

	<div class="listType_1__item">
		<div class="listType_1__item__info">
			<div class="listType_1__item__discount">
	            <p>Экономия</p>
	            <h5>2747 грн</h5>
	        </div>
	        <span class="listType_1__item__pay"></span>
	    </div>
		<figure class="listType_1__pic">
			<div class="listType_1__img">
				<img src="uploads/your_city-dveri-mezhkomnatnye-metalloplastikovye/catalog/window_2.jpg" alt="">
			</div>
		</figure>
		<div class="listType_1__footer">
			<p class="asPrice_withoutDiscount">Цена без скидки от <span class="line-through">9158 грн</span></p>
			<div class="asPrice">
				Цена от
				<span class="asPrice__count">6411</span>
				<span class="asPrice__currency">грн</span>
			</div>
			<a class="js-callModal asBtnLink asBtnLink--primary" href="#" title="ЗАЯВКА НА ПОКУПКУ ДВЕРЕЙ">Заказать</a>
		</div>
	</div>

	<div class="listType_1__item">
		<div class="listType_1__item__info">
			<div class="listType_1__item__discount">
	            <p>Экономия</p>
	            <h5>2692 грн</h5>
	        </div>
	        <span class="listType_1__item__pay"></span>
	    </div>
		<figure class="listType_1__pic">
			<div class="listType_1__img">
				<img src="uploads/your_city-dveri-mezhkomnatnye-metalloplastikovye/catalog/window_3.jpg" alt="">
			</div>
		</figure>
		<div class="listType_1__footer">
			<p class="asPrice_withoutDiscount">Цена без скидки от <span class="line-through">8971 грн</span></p>
			<div class="asPrice">
				Цена от
				<span class="asPrice__count">6279</span>
				<span class="asPrice__currency">грн</span>
			</div>
			<a class="js-callModal asBtnLink asBtnLink--primary" href="#" title="ЗАЯВКА НА ПОКУПКУ ДВЕРЕЙ">Заказать</a>
		</div>
	</div>

	<div class="listType_1__item">
		<div class="listType_1__item__info">
			<div class="listType_1__item__discount">
	            <p>Экономия</p>
	            <h5>2608 грн</h5>
	        </div>
	        <span class="listType_1__item__pay"></span>
	    </div>
		<figure class="listType_1__pic">
			<div class="listType_1__img">
				<img src="uploads/your_city-dveri-mezhkomnatnye-metalloplastikovye/catalog/window_4.jpg" alt="">
			</div>
		</figure>
		<div class="listType_1__footer">
			<p class="asPrice_withoutDiscount">Цена без скидки от <span class="line-through">8696 грн</span></p>
			<div class="asPrice">
				Цена от
				<span class="asPrice__count">6088</span>
				<span class="asPrice__currency">грн</span>
			</div>
			<a class="js-callModal asBtnLink asBtnLink--primary" href="#" title="ЗАЯВКА НА ПОКУПКУ ДВЕРЕЙ">Заказать</a>
		</div>
	</div>

	<div class="listType_1__item">
		<div class="listType_1__item__info">
			<div class="listType_1__item__discount">
	            <p>Экономия</p>
	            <h5>4105 грн</h5>
	        </div>
	        <span class="listType_1__item__pay"></span>
	    </div>
		<figure class="listType_1__pic">
			<div class="listType_1__img">
				<img src="uploads/your_city-dveri-mezhkomnatnye-metalloplastikovye/catalog/window_5.jpg" alt="">
			</div>
		</figure>
		<div class="listType_1__footer">
			<p class="asPrice_withoutDiscount">Цена без скидки от <span class="line-through">13564 грн</span></p>
			<div class="asPrice">
				Цена от
				<span class="asPrice__count">9459</span>
				<span class="asPrice__currency">грн</span>
			</div>
			<a class="js-callModal asBtnLink asBtnLink--primary" href="#" title="ЗАЯВКА НА ПОКУПКУ ДВЕРЕЙ">Заказать</a>
		</div>
	</div>

	<div class="listType_1__item">
		<div class="listType_1__item__info">
			<div class="listType_1__item__discount">
	            <p>Экономия</p>
	            <h5>4222 грн</h5>
	        </div>
	        <span class="listType_1__item__pay"></span>
	    </div>
		<figure class="listType_1__pic">
			<div class="listType_1__img">
				<img src="uploads/your_city-dveri-mezhkomnatnye-metalloplastikovye/catalog/window_6.jpg" alt="">
			</div>
		</figure>
		<div class="listType_1__footer">
			<p class="asPrice_withoutDiscount">Цена без скидки от <span class="line-through">14072 грн</span></p>
			<div class="asPrice">
				Цена от
				<span class="asPrice__count">9850</span>
				<span class="asPrice__currency">грн</span>
			</div>
			<a class="js-callModal asBtnLink asBtnLink--primary" href="#" title="ЗАЯВКА НА ПОКУПКУ ДВЕРЕЙ">Заказать</a>
		</div>
	</div>

	<div class="listType_1__item">
		<div class="listType_1__item__info">
			<div class="listType_1__item__discount">
	            <p>Экономия</p>
	            <h5>4134 грн</h5>
	        </div>
	        <span class="listType_1__item__pay"></span>
	    </div>
		<figure class="listType_1__pic">
			<div class="listType_1__img">
				<img src="uploads/your_city-dveri-mezhkomnatnye-metalloplastikovye/catalog/window_7.jpg" alt="">
			</div>
		</figure>
		<div class="listType_1__footer">
			<p class="asPrice_withoutDiscount">Цена без скидки от <span class="line-through">13779 грн</span></p>
			<div class="asPrice">
				Цена от
				<span class="asPrice__count">9645</span>
				<span class="asPrice__currency">грн</span>
			</div>
			<a class="js-callModal asBtnLink asBtnLink--primary" href="#" title="ЗАЯВКА НА ПОКУПКУ ДВЕРЕЙ">Заказать</a>
		</div>
	</div>

	<div class="listType_1__item">
		<div class="listType_1__item__info">
			<div class="listType_1__item__discount">
	            <p>Экономия</p>
	            <h5>4003 грн</h5>
	        </div>
	        <span class="listType_1__item__pay"></span>
	    </div>
		<figure class="listType_1__pic">
			<div class="listType_1__img">
				<img src="uploads/your_city-dveri-mezhkomnatnye-metalloplastikovye/catalog/window_8.jpg" alt="">
			</div>
		</figure>
		<div class="listType_1__footer">
			<p class="asPrice_withoutDiscount">Цена без скидки от <span class="line-through">13344 грн</span></p>
			<div class="asPrice">
				Цена от
				<span class="asPrice__count">9341</span>
				<span class="asPrice__currency">грн</span>
			</div>
			<a class="js-callModal asBtnLink asBtnLink--primary" href="#" title="ЗАЯВКА НА ПОКУПКУ ДВЕРЕЙ">Заказать</a>
		</div>
	</div>

	<div class="listType_1__item">
		<div class="listType_1__item__info">
			<div class="listType_1__item__discount">
	            <p>Экономия</p>
	            <h5>4312 грн</h5>
	        </div>
	        <span class="listType_1__item__pay"></span>
	    </div>
		<figure class="listType_1__pic">
			<div class="listType_1__img">
				<img src="uploads/your_city-dveri-mezhkomnatnye-metalloplastikovye/catalog/window_9.jpg" alt="">
			</div>
		</figure>
		<div class="listType_1__footer">
			<p class="asPrice_withoutDiscount">Цена без скидки от <span class="line-through">14372 грн</span></p>
			<div class="asPrice">
				Цена от
				<span class="asPrice__count">10060</span>
				<span class="asPrice__currency">грн</span>
			</div>
			<a class="js-callModal asBtnLink asBtnLink--primary" href="#" title="ЗАЯВКА НА ПОКУПКУ ДВЕРЕЙ">Заказать</a>
		</div>
	</div>

	<div class="listType_1__item">
		<div class="listType_1__item__info">
			<div class="listType_1__item__discount">
	            <p>Экономия</p>
	            <h5>4493 грн</h5>
	        </div>
	        <span class="listType_1__item__pay"></span>
	    </div>
		<figure class="listType_1__pic">
			<div class="listType_1__img">
				<img src="uploads/your_city-dveri-mezhkomnatnye-metalloplastikovye/catalog/window_10.jpg" alt="">
			</div>
		</figure>
		<div class="listType_1__footer">
			<p class="asPrice_withoutDiscount">Цена без скидки от <span class="line-through">14975 грн</span></p>
			<div class="asPrice">
				Цена от
				<span class="asPrice__count">10482</span>
				<span class="asPrice__currency">грн</span>
			</div>
			<a class="js-callModal asBtnLink asBtnLink--primary" href="#" title="ЗАЯВКА НА ПОКУПКУ ДВЕРЕЙ">Заказать</a>
		</div>
	</div>

	<div class="listType_1__item">
		<div class="listType_1__item__info">
			<div class="listType_1__item__discount">
	            <p>Экономия</p>
	            <h5>4378 грн</h5>
	        </div>
	        <span class="listType_1__item__pay"></span>
	    </div>
		<figure class="listType_1__pic">
			<div class="listType_1__img">
				<img src="uploads/your_city-dveri-mezhkomnatnye-metalloplastikovye/catalog/window_11.jpg" alt="">
			</div>
		</figure>
		<div class="listType_1__footer">
			<p class="asPrice_withoutDiscount">Цена без скидки от <span class="line-through">14593 грн</span></p>
			<div class="asPrice">
				Цена от
				<span class="asPrice__count">10215</span>
				<span class="asPrice__currency">грн</span>
			</div>
			<a class="js-callModal asBtnLink asBtnLink--primary" href="#" title="ЗАЯВКА НА ПОКУПКУ ДВЕРЕЙ">Заказать</a>
		</div>
	</div>

	<div class="listType_1__item">
		<div class="listType_1__item__info">
			<div class="listType_1__item__discount">
	            <p>Экономия</p>
	            <h5>4205 грн</h5>
	        </div>
	        <span class="listType_1__item__pay"></span>
	    </div>
		<figure class="listType_1__pic">
			<div class="listType_1__img">
				<img src="uploads/your_city-dveri-mezhkomnatnye-metalloplastikovye/catalog/window_12.jpg" alt="">
			</div>
		</figure>
		<div class="listType_1__footer">
			<p class="asPrice_withoutDiscount">Цена без скидки от <span class="line-through">14017 грн</span></p>
			<div class="asPrice">
				Цена от
				<span class="asPrice__count">9812</span>
				<span class="asPrice__currency">грн</span>
			</div>
			<a class="js-callModal asBtnLink asBtnLink--primary" href="#" title="ЗАЯВКА НА ПОКУПКУ ДВЕРЕЙ">Заказать</a>
		</div>
	</div>

	<div class="listType_1__item">
		<div class="listType_1__item__info">
			<div class="listType_1__item__discount">
	            <p>Экономия</p>
	            <h5>3568 грн</h5>
	        </div>
	        <span class="listType_1__item__pay"></span>
	    </div>
		<figure class="listType_1__pic">
			<div class="listType_1__img">
				<img src="uploads/your_city-dveri-mezhkomnatnye-metalloplastikovye/catalog/window_13.jpg" alt="">
			</div>
		</figure>
		<div class="listType_1__footer">
			<p class="asPrice_withoutDiscount">Цена без скидки от <span class="line-through">11894 грн</span></p>
			<div class="asPrice">
				Цена от
				<span class="asPrice__count">8326</span>
				<span class="asPrice__currency">грн</span>
			</div>
			<a class="js-callModal asBtnLink asBtnLink--primary" href="#" title="ЗАЯВКА НА ПОКУПКУ ДВЕРЕЙ">Заказать</a>
		</div>
	</div>

	<div class="listType_1__item">
		<div class="listType_1__item__info">
			<div class="listType_1__item__discount">
	            <p>Экономия</p>
	            <h5>3732 грн</h5>
	        </div>
	        <span class="listType_1__item__pay"></span>
	    </div>
		<figure class="listType_1__pic">
			<div class="listType_1__img">
				<img src="uploads/your_city-dveri-mezhkomnatnye-metalloplastikovye/catalog/window_14.jpg" alt="">
			</div>
		</figure>
		<div class="listType_1__footer">
			<p class="asPrice_withoutDiscount">Цена без скидки от <span class="line-through">12440 грн</span></p>
			<div class="asPrice">
				Цена от
				<span class="asPrice__count">8708</span>
				<span class="asPrice__currency">грн</span>
			</div>
			<a class="js-callModal asBtnLink asBtnLink--primary" href="#" title="ЗАЯВКА НА ПОКУПКУ ДВЕРЕЙ">Заказать</a>
		</div>
	</div>

	<div class="listType_1__item">
		<div class="listType_1__item__info">
			<div class="listType_1__item__discount">
	            <p>Экономия</p>
	            <h5>3630 грн</h5>
	        </div>
	        <span class="listType_1__item__pay"></span>
	    </div>
		<figure class="listType_1__pic">
			<div class="listType_1__img">
				<img src="uploads/your_city-dveri-mezhkomnatnye-metalloplastikovye/catalog/window_15.jpg" alt="">
			</div>
		</figure>
		<div class="listType_1__footer">
			<p class="asPrice_withoutDiscount">Цена без скидки от <span class="line-through">12101 грн</span></p>
			<div class="asPrice">
				Цена от
				<span class="asPrice__count">8471</span>
				<span class="asPrice__currency">грн</span>
			</div>
			<a class="js-callModal asBtnLink asBtnLink--primary" href="#" title="ЗАЯВКА НА ПОКУПКУ ДВЕРЕЙ">Заказать</a>
		</div>
	</div>

	<div class="listType_1__item">
		<div class="listType_1__item__info">
			<div class="listType_1__item__discount">
	            <p>Экономия</p>
	            <h5>3480 грн</h5>
	        </div>
	        <span class="listType_1__item__pay"></span>
	    </div>
		<figure class="listType_1__pic">
			<div class="listType_1__img">
				<img src="uploads/your_city-dveri-mezhkomnatnye-metalloplastikovye/catalog/window_16.jpg" alt="">
			</div>
		</figure>
		<div class="listType_1__footer">
			<p class="asPrice_withoutDiscount">Цена без скидки от <span class="line-through">11598 грн</span></p>
			<div class="asPrice">
				Цена от
				<span class="asPrice__count">8118</span>
				<span class="asPrice__currency">грн</span>
			</div>
			<a class="js-callModal asBtnLink asBtnLink--primary" href="#" title="ЗАЯВКА НА ПОКУПКУ ДВЕРЕЙ">Заказать</a>
		</div>
	</div>

	

</div>