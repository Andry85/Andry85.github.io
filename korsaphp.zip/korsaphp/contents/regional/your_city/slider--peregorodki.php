<div class="asCarousel">
	<div class="owl-carousel">
		<div class="asCarousel__item">
			<a href="uploads/your_city/peregorodki/001.jpg" data-fancybox="plascicImages-6">
				<img src="uploads/your_city/peregorodki/001.jpg" alt="">
			</a>	
			<a href="uploads/your_city/peregorodki/002.jpg" data-fancybox="plascicImages-6">
				<img src="uploads/your_city/peregorodki/002.jpg" alt="">
			</a>
		</div>
		<div class="asCarousel__item">
			<a href="uploads/your_city/peregorodki/003.jpg" data-fancybox="plascicImages-6">
				<img src="uploads/your_city/peregorodki/003.jpg" alt="">
			</a>	
			<a href="uploads/your_city/peregorodki/004.jpg" data-fancybox="plascicImages-6">
				<img src="uploads/your_city/peregorodki/004.jpg" alt="">
			</a>
		</div>
		<div class="asCarousel__item">
			<a href="uploads/your_city/peregorodki/005.jpg" data-fancybox="plascicImages-6">
				<img src="uploads/your_city/peregorodki/005.jpg" alt="">
			</a>	
			<a href="uploads/your_city/peregorodki/006.jpg" data-fancybox="plascicImages-6">
				<img src="uploads/your_city/peregorodki/006.jpg" alt="">
			</a>
		</div>
		<div class="asCarousel__item">
			<a href="uploads/your_city/peregorodki/007.jpg" data-fancybox="plascicImages-6">
				<img src="uploads/your_city/peregorodki/007.jpg" alt="">
			</a>	
			<a href="uploads/your_city/peregorodki/008.jpg" data-fancybox="plascicImages-6">
				<img src="uploads/your_city/peregorodki/008.jpg" alt="">
			</a>
		</div>	
	</div>
</div>