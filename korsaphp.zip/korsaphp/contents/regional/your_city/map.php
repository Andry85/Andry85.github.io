<div class="asOfficeMap">
	<div class="row">
		<div class="col-sm-7">
			<div class="asOfficeMap__map">
				<iframe src="https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d20840.95754144656!2d28.46152277392579!3d49.2362198648876!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e0!3m2!1sru!2sua!4v1561979824201!5m2!1sru!2sua" allowfullscreen></iframe>
			</div>
		</div>
		<div class="col-sm-5">
			<div class="asOfficeMapEntry">
				<h3 class="asOfficeMapEntry__title">Звоните уже сейчас!</h3>
				<p class="asOfficeMapEntry__text">Получайте исчерпывающие ответы на свои вопросы от наших менеджеров и оформляйте заказ.</p>
				<div class="asLinksWrap">
					<a class="js-callModal asBtnLink asBtnLink--default" href="#" title="ЗАЯВКА НА КОНСУЛЬТАЦИЮ">получить консультацию</a>
					<a class="js-callModal asBtnLink asBtnLink--primary" href="#" title="ЗАЯВКА НА ОБРАТНЫЙ ЗВОНОК">обратный звонок</a>
				</div>		
			</div>
		</div>
	</div>
</div>