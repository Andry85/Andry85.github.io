<div class="asCarousel">
	<div class="owl-carousel">
		<div class="asCarousel__item">
			<a href="uploads/your_city/dveri/001.jpg" data-fancybox="plascicImages-3">
				<img src="uploads/your_city/dveri/001.jpg" alt="">
			</a>	
			<a href="uploads/your_city/dveri/002.jpg" data-fancybox="plascicImages-3">
				<img src="uploads/your_city/dveri/002.jpg" alt="">
			</a>
		</div>
		<div class="asCarousel__item">
			<a href="uploads/your_city/dveri/003.jpg" data-fancybox="plascicImages-3">
				<img src="uploads/your_city/dveri/003.jpg" alt="">
			</a>	
			<a href="uploads/your_city/dveri/004.jpg" data-fancybox="plascicImages-3">
				<img src="uploads/your_city/dveri/004.jpg" alt="">
			</a>
		</div>
		<div class="asCarousel__item">
			<a href="uploads/your_city/dveri/005.jpg" data-fancybox="plascicImages-3">
				<img src="uploads/your_city/dveri/005.jpg" alt="">
			</a>	
			<a href="uploads/your_city/dveri/006.jpg" data-fancybox="plascicImages-3">
				<img src="uploads/your_city/dveri/006.jpg" alt="">
			</a>
		</div>
		<div class="asCarousel__item">
			<a href="uploads/your_city/dveri/007.jpg" data-fancybox="plascicImages-3">
				<img src="uploads/your_city/dveri/007.jpg" alt="">
			</a>	
			<a href="uploads/your_city/dveri/008.jpg" data-fancybox="plascicImages-3">
				<img src="uploads/your_city/dveri/008.jpg" alt="">
			</a>
		</div>	
	</div>
</div>