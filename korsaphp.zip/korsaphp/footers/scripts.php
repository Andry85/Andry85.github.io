<!-- Scripts -->
	<script src="css/fontawesome-free-5.9.0-web/js/all.js"></script>
	<script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
	<script src="js/jquery.slicknav.js"></script>
	<script src="js/jquery.validate.min.js"></script>
	<script src="js/jquery.fancybox.min.js"></script>
	<script src="js/owl.carousel.min.js"></script>
	<script src="js/jquery.scrollbar.min.js"></script>
	<script src="js/main.js"></script>

	
