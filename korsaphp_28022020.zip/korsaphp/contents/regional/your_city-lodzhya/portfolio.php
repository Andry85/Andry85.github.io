<section class="asGoods">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<h2 class="asGoods__title asGoods__title--examples">Примеры наших работ</h2>
				<!-- Slider Start -->
					<div class="asCarousel--big">
						<div class="owl-carousel">
							<div class="asCarousel--big__item">
								<a href="uploads/your_city-lodzhya/001.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-lodzhya/001.jpg" alt="">
								</a>
								<a href="uploads/your_city-lodzhya/002.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-lodzhya/002.jpg" alt="">
								</a>
								<a href="uploads/your_city-lodzhya/003.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-lodzhya/003.jpg" alt="">
								</a>
								<a href="uploads/your_city-lodzhya/004.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-lodzhya/004.jpg" alt="">
								</a>
							</div>
							<div class="asCarousel--big__item">
								<a href="uploads/your_city-lodzhya/005.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-lodzhya/005.jpg" alt="">
								</a>
								<a href="uploads/your_city-lodzhya/006.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-lodzhya/006.jpg" alt="">
								</a>
								<a href="uploads/your_city-lodzhya/007.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-lodzhya/007.jpg" alt="">
								</a>
								<a href="uploads/your_city-lodzhya/008.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-lodzhya/008.jpg" alt="">
								</a>
							</div>
							<div class="asCarousel--big__item">
								<a href="uploads/your_city-lodzhya/009.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-lodzhya/009.jpg" alt="">
								</a>
								<a href="uploads/your_city-lodzhya/010.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-lodzhya/010.jpg" alt="">
								</a>
								<a href="uploads/your_city-lodzhya/011.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-lodzhya/011.jpg" alt="">
								</a>
								<a href="uploads/your_city-lodzhya/012.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-lodzhya/012.jpg" alt="">
								</a>
							</div>
							<div class="asCarousel--big__item">
								<a href="uploads/your_city-lodzhya/013.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-lodzhya/013.jpg" alt="">
								</a>
								<a href="uploads/your_city-lodzhya/014.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-lodzhya/014.jpg" alt="">
								</a>
								<a href="uploads/your_city-lodzhya/015.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-lodzhya/015.jpg" alt="">
								</a>
								<a href="uploads/your_city-lodzhya/016.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-lodzhya/016.jpg" alt="">
								</a>
							</div>
							<div class="asCarousel--big__item">
								<a href="uploads/your_city-lodzhya/017.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-lodzhya/017.jpg" alt="">
								</a>
							</div>
						</div>
					</div>
				<!-- Slider End -->
					
			</div>
		</div>
	</div>
</section>