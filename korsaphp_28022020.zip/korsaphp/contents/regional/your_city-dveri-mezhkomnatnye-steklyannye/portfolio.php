<section class="asGoods">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<h2 class="asGoods__title asGoods__title--examples">Примеры наших работ</h2>
				<!-- Slider Start -->
					<div class="asCarousel--big">
						<div class="owl-carousel">
							<div class="asCarousel--big__item">
								<a href="uploads/your_city-dveri-mezhkomnatnye-steklyannye/001.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-dveri-mezhkomnatnye-steklyannye/001.jpg" alt="">
								</a>
								<a href="uploads/your_city-dveri-mezhkomnatnye-steklyannye/002.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-dveri-mezhkomnatnye-steklyannye/002.jpg" alt="">
								</a>
								<a href="uploads/your_city-dveri-mezhkomnatnye-steklyannye/003.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-dveri-mezhkomnatnye-steklyannye/003.jpg" alt="">
								</a>
								<a href="uploads/your_city-dveri-mezhkomnatnye-steklyannye/004.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-dveri-mezhkomnatnye-steklyannye/004.jpg" alt="">
								</a>
							</div>
							<div class="asCarousel--big__item">
								<a href="uploads/your_city-dveri-mezhkomnatnye-steklyannye/005.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-dveri-mezhkomnatnye-steklyannye/005.jpg" alt="">
								</a>
								<a href="uploads/your_city-dveri-mezhkomnatnye-steklyannye/006.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-dveri-mezhkomnatnye-steklyannye/006.jpg" alt="">
								</a>
								<a href="uploads/your_city-dveri-mezhkomnatnye-steklyannye/007.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-dveri-mezhkomnatnye-steklyannye/007.jpg" alt="">
								</a>
								<a href="uploads/your_city-dveri-mezhkomnatnye-steklyannye/008.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-dveri-mezhkomnatnye-steklyannye/008.jpg" alt="">
								</a>
							</div>
							<div class="asCarousel--big__item">
								<a href="uploads/your_city-dveri-mezhkomnatnye-steklyannye/009.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-dveri-mezhkomnatnye-steklyannye/009.jpg" alt="">
								</a>
								<a href="uploads/your_city-dveri-mezhkomnatnye-steklyannye/010.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-dveri-mezhkomnatnye-steklyannye/010.jpg" alt="">
								</a>
								<a href="uploads/your_city-dveri-mezhkomnatnye-steklyannye/011.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-dveri-mezhkomnatnye-steklyannye/011.jpg" alt="">
								</a>
								<a href="uploads/your_city-dveri-mezhkomnatnye-steklyannye/012.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-dveri-mezhkomnatnye-steklyannye/012.jpg" alt="">
								</a>
							</div>
							<div class="asCarousel--big__item">
								<a href="uploads/your_city-dveri-mezhkomnatnye-steklyannye/013.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-dveri-mezhkomnatnye-steklyannye/013.jpg" alt="">
								</a>
								<a href="uploads/your_city-dveri-mezhkomnatnye-steklyannye/014.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-dveri-mezhkomnatnye-steklyannye/014.jpg" alt="">
								</a>
								<a href="uploads/your_city-dveri-mezhkomnatnye-steklyannye/015.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-dveri-mezhkomnatnye-steklyannye/015.jpg" alt="">
								</a>
								<a href="uploads/your_city-dveri-mezhkomnatnye-steklyannye/016.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-dveri-mezhkomnatnye-steklyannye/016.jpg" alt="">
								</a>
							</div>
							<div class="asCarousel--big__item">
								<a href="uploads/your_city-dveri-mezhkomnatnye-steklyannye/017.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-dveri-mezhkomnatnye-steklyannye/017.jpg" alt="">
								</a>
								<a href="uploads/your_city-dveri-mezhkomnatnye-steklyannye/018.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-dveri-mezhkomnatnye-steklyannye/018.jpg" alt="">
								</a>
								<a href="uploads/your_city-dveri-mezhkomnatnye-steklyannye/019.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-dveri-mezhkomnatnye-steklyannye/019.jpg" alt="">
								</a>
								<a href="uploads/your_city-dveri-mezhkomnatnye-steklyannye/020.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-dveri-mezhkomnatnye-steklyannye/020.jpg" alt="">
								</a>
							</div>
							
								
						</div>
					</div>
				<!-- Slider End -->
					
			</div>
		</div>
	</div>
</section>