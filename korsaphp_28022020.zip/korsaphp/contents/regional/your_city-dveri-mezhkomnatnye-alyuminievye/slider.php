<div class="asCarousel">
	<div class="owl-carousel">
		<div class="asCarousel__item">
			<a href="uploads/your_city-dveri-mezhkomnatnye-alyuminievye/001.jpg" data-fancybox="plascicImages-1">
				<img src="uploads/your_city-dveri-mezhkomnatnye-alyuminievye/001.jpg" alt="">
			</a>	
			<a href="uploads/your_city-dveri-mezhkomnatnye-alyuminievye/002.jpg" data-fancybox="plascicImages-1">
				<img src="uploads/your_city-dveri-mezhkomnatnye-alyuminievye/002.jpg" alt="">
			</a>
		</div>
		<div class="asCarousel__item">	
			<a href="uploads/your_city-dveri-mezhkomnatnye-alyuminievye/003.jpg" data-fancybox="plascicImages-1">
				<img src="uploads/your_city-dveri-mezhkomnatnye-alyuminievye/003.jpg" alt="">
			</a>	
			<a href="uploads/your_city-dveri-mezhkomnatnye-alyuminievye/004.jpg" data-fancybox="plascicImages-1">
				<img src="uploads/your_city-dveri-mezhkomnatnye-alyuminievye/004.jpg" alt="">
			</a>
		</div>
		<div class="asCarousel__item">
			<a href="uploads/your_city-dveri-mezhkomnatnye-alyuminievye/005.jpg" data-fancybox="plascicImages-1">
				<img src="uploads/your_city-dveri-mezhkomnatnye-alyuminievye/005.jpg" alt="">
			</a>	
			<a href="uploads/your_city-dveri-mezhkomnatnye-alyuminievye/006.jpg" data-fancybox="plascicImages-1">
				<img src="uploads/your_city-dveri-mezhkomnatnye-alyuminievye/006.jpg" alt="">
			</a>
		</div>
		<div class="asCarousel__item">	
			<a href="uploads/your_city-dveri-mezhkomnatnye-alyuminievye/007.jpg" data-fancybox="plascicImages-1">
				<img src="uploads/your_city-dveri-mezhkomnatnye-alyuminievye/007.jpg" alt="">
			</a>	
			<a href="uploads/your_city-dveri-mezhkomnatnye-alyuminievye/008.jpg" data-fancybox="plascicImages-1">
				<img src="uploads/your_city-dveri-mezhkomnatnye-alyuminievye/008.jpg" alt="">
			</a>
		</div>
	</div>
</div>