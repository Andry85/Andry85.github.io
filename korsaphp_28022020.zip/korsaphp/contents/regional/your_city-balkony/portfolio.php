<section class="asGoods">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<h2 class="asGoods__title asGoods__title--examples">Примеры наших работ</h2>
				<!-- Slider Start -->
					<div class="asCarousel--big">
						<div class="owl-carousel">
							<div class="asCarousel--big__item">
								<a href="uploads/your_city-balkony/001.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-balkony/001.jpg" alt="">
								</a>
								<a href="uploads/your_city-balkony/002.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-balkony/002.jpg" alt="">
								</a>
								<a href="uploads/your_city-balkony/003.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-balkony/003.jpg" alt="">
								</a>
								<a href="uploads/your_city-balkony/004.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-balkony/004.jpg" alt="">
								</a>
							</div>
							<div class="asCarousel--big__item">
								<a href="uploads/your_city-balkony/005.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-balkony/005.jpg" alt="">
								</a>
								<a href="uploads/your_city-balkony/006.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-balkony/006.jpg" alt="">
								</a>
								<a href="uploads/your_city-balkony/007.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-balkony/007.jpg" alt="">
								</a>
								<a href="uploads/your_city-balkony/008.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-balkony/008.jpg" alt="">
								</a>
							</div>
							<div class="asCarousel--big__item">
								<a href="uploads/your_city-balkony/009.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-balkony/009.jpg" alt="">
								</a>
								<a href="uploads/your_city-balkony/010.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-balkony/010.jpg" alt="">
								</a>
								<a href="uploads/your_city-balkony/011.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-balkony/011.jpg" alt="">
								</a>
								<a href="uploads/your_city-balkony/012.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-balkony/012.jpg" alt="">
								</a>
							</div>
							<div class="asCarousel--big__item">
								<a href="uploads/your_city-balkony/013.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-balkony/013.jpg" alt="">
								</a>
								<a href="uploads/your_city-balkony/014.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-balkony/014.jpg" alt="">
								</a>
								<a href="uploads/your_city-balkony/015.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-balkony/015.jpg" alt="">
								</a>
								<a href="uploads/your_city-balkony/016.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-balkony/016.jpg" alt="">
								</a>
							</div>
							<div class="asCarousel--big__item">
								<a href="uploads/your_city-balkony/017.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-balkony/017.jpg" alt="">
								</a>
								<a href="uploads/your_city-balkony/018.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-balkony/018.jpg" alt="">
								</a>
								<a href="uploads/your_city-balkony/019.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-balkony/019.jpg" alt="">
								</a>
								<a href="uploads/your_city-balkony/020.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-balkony/020.jpg" alt="">
								</a>
							</div>
							<div class="asCarousel--big__item">
								<a href="uploads/your_city-balkony/021.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-balkony/021.jpg" alt="">
								</a>
								<a href="uploads/your_city-balkony/022.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-balkony/022.jpg" alt="">
								</a>
								<a href="uploads/your_city-balkony/023.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-balkony/023.jpg" alt="">
								</a>
								<a href="uploads/your_city-balkony/024.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-balkony/024.jpg" alt="">
								</a>
							</div>
							<div class="asCarousel--big__item">
								<a href="uploads/your_city-balkony/025.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-balkony/025.jpg" alt="">
								</a>
								<a href="uploads/your_city-balkony/026.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-balkony/026.jpg" alt="">
								</a>
								<a href="uploads/your_city-balkony/027.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-balkony/027.jpg" alt="">
								</a>
								<a href="uploads/your_city-balkony/028.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-balkony/028.jpg" alt="">
								</a>
							</div>
							<div class="asCarousel--big__item">
								<a href="uploads/your_city-balkony/029.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-balkony/029.jpg" alt="">
								</a>
								<a href="uploads/your_city-balkony/030.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-balkony/030.jpg" alt="">
								</a>
								<a href="uploads/your_city-balkony/031.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-balkony/031.jpg" alt="">
								</a>
								<a href="uploads/your_city-balkony/032.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-balkony/032.jpg" alt="">
								</a>
							</div>
							<div class="asCarousel--big__item">
								<a href="uploads/your_city-balkony/033.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-balkony/033.jpg" alt="">
								</a>
								<a href="uploads/your_city-balkony/034.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-balkony/034.jpg" alt="">
								</a>
								<a href="uploads/your_city-balkony/035.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-balkony/035.jpg" alt="">
								</a>
								<a href="uploads/your_city-balkony/036.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-balkony/036.jpg" alt="">
								</a>
							</div>
							<div class="asCarousel--big__item">
								<a href="uploads/your_city-balkony/037.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-balkony/037.jpg" alt="">
								</a>
								<a href="uploads/your_city-balkony/038.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-balkony/038.jpg" alt="">
								</a>
								<a href="uploads/your_city-balkony/039.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-balkony/039.jpg" alt="">
								</a>
								<a href="uploads/your_city-balkony/040.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-balkony/040.jpg" alt="">
								</a>
							</div>
							<div class="asCarousel--big__item">
								<a href="uploads/your_city-balkony/041.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-balkony/041.jpg" alt="">
								</a>
								<a href="uploads/your_city-balkony/042.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-balkony/042.jpg" alt="">
								</a>
								<a href="uploads/your_city-balkony/043.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-balkony/043.jpg" alt="">
								</a>
								<a href="uploads/your_city-balkony/044.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-balkony/044.jpg" alt="">
								</a>
							</div>
							<div class="asCarousel--big__item">
								<a href="uploads/your_city-balkony/045.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-balkony/045.jpg" alt="">
								</a>
								<a href="uploads/your_city-balkony/046.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-balkony/046.jpg" alt="">
								</a>
								<a href="uploads/your_city-balkony/047.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-balkony/047.jpg" alt="">
								</a>
								<a href="uploads/your_city-balkony/048.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-balkony/048.jpg" alt="">
								</a>
							</div>
							<div class="asCarousel--big__item">
								<a href="uploads/your_city-balkony/049.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-balkony/049.jpg" alt="">
								</a>
								<a href="uploads/your_city-balkony/050.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-balkony/050.jpg" alt="">
								</a>
								<a href="uploads/your_city-balkony/051.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-balkony/051.jpg" alt="">
								</a>
								<a href="uploads/your_city-balkony/052.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-balkony/052.jpg" alt="">
								</a>
							</div>
							<div class="asCarousel--big__item">
								<a href="uploads/your_city-balkony/053.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-balkony/053.jpg" alt="">
								</a>
								<a href="uploads/your_city-balkony/054.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-balkony/054.jpg" alt="">
								</a>
								<a href="uploads/your_city-balkony/055.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-balkony/055.jpg" alt="">
								</a>
								<a href="uploads/your_city-balkony/056.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-balkony/056.jpg" alt="">
								</a>
							</div>
							<div class="asCarousel--big__item">
								<a href="uploads/your_city-balkony/057.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-balkony/057.jpg" alt="">
								</a>
								<a href="uploads/your_city-balkony/058.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-balkony/058.jpg" alt="">
								</a>
							</div>
						</div>
					</div>
				<!-- Slider End -->
					
			</div>
		</div>
	</div>
</section>