<section class="asGoods">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<h2 class="asGoods__title asGoods__title--examples">Примеры наших работ</h2>
				<!-- Slider Start -->
					<div class="asCarousel--big">
						<div class="owl-carousel">
							<div class="asCarousel--big__item">
								<a href="uploads/your_city-dveri-vhodnye-metalloplastikovye/001.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-dveri-vhodnye-metalloplastikovye/001.jpg" alt="">
								</a>	
								<a href="uploads/your_city-dveri-vhodnye-metalloplastikovye/002.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-dveri-vhodnye-metalloplastikovye/002.jpg" alt="">
								</a>
								<a href="uploads/your_city-dveri-vhodnye-metalloplastikovye/003.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-dveri-vhodnye-metalloplastikovye/003.jpg" alt="">
								</a>	
								<a href="uploads/your_city-dveri-vhodnye-metalloplastikovye/004.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-dveri-vhodnye-metalloplastikovye/004.jpg" alt="">
								</a>
							</div>
							<div class="asCarousel--big__item">
								<a href="uploads/your_city-dveri-vhodnye-metalloplastikovye/005.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-dveri-vhodnye-metalloplastikovye/005.jpg" alt="">
								</a>
								<a href="uploads/your_city-dveri-vhodnye-alyuminievye/001.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-dveri-vhodnye-alyuminievye/001.jpg" alt="">
								</a>
								<a href="uploads/your_city-dveri-vhodnye-alyuminievye/002.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-dveri-vhodnye-alyuminievye/002.jpg" alt="">
								</a>
								<a href="uploads/your_city-dveri-vhodnye-alyuminievye/003.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-dveri-vhodnye-alyuminievye/003.jpg" alt="">
								</a>
							</div>
							<div class="asCarousel--big__item">
								<a href="uploads/your_city-dveri-vhodnye-alyuminievye/004.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-dveri-vhodnye-alyuminievye/004.jpg" alt="">
								</a>
								<a href="uploads/your_city-dveri-vhodnye-alyuminievye/005.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-dveri-vhodnye-alyuminievye/005.jpg" alt="">
								</a>
								<a href="uploads/your_city-dveri-vhodnye-metallicheskie/001.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-dveri-vhodnye-metallicheskie/001.jpg" alt="">
								</a>
								<a href="uploads/your_city-dveri-vhodnye-metallicheskie/002.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-dveri-vhodnye-metallicheskie/002.jpg" alt="">
								</a>
							</div>
							<div class="asCarousel--big__item">
								<a href="uploads/your_city-dveri-vhodnye-metallicheskie/003.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-dveri-vhodnye-metallicheskie/003.jpg" alt="">
								</a>
								<a href="uploads/your_city-dveri-vhodnye-metallicheskie/004.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-dveri-vhodnye-metallicheskie/004.jpg" alt="">
								</a>
								<a href="uploads/your_city-dveri-vhodnye-metallicheskie/005.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-dveri-vhodnye-metallicheskie/005.jpg" alt="">
								</a>
								<a href="uploads/your_city-dveri-vhodnye-metallicheskie/006.jpg" data-fancybox="plascicImages">
									<img src="uploads/your_city-dveri-vhodnye-metallicheskie/006.jpg" alt="">
								</a>

							</div>	
						</div>
					</div>
				<!-- Slider End -->
					
			</div>
		</div>
	</div>
</section>