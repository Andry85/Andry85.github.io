<div class="listType_1">

	<div class="listType_1__item">
		<div class="listType_1__item__info">
			<div class="listType_1__item__discount">
	            <p>Экономия</p>
	            <h5>4312 грн</h5>
	        </div>
	    </div>
		<figure class="listType_1__pic">
			<div class="listType_1__img">
				<img src="uploads/your_city-balkon-plastikovyj/slider_02/001.jpg" alt="">
			</div>
			<figcaption class="listType_1__title">Балконный блок, дверь с панелью и окно с открыванием</figcaption>
		</figure>
		<div class="listType_1__footer">
			<p class="asPrice_withoutDiscount">Цена без скидки от <span class="line-through">14372 грн</span></p>
			<div class="asPrice">
				Цена от
				<span class="asPrice__count">10060</span>
				<span class="asPrice__currency">грн</span>
			</div>
			<a class="js-callModal asBtnLink asBtnLink--primary" href="#" title="ЗАЯВКА НА ПОКУПКУ балкона">Заказать</a>
		</div>
	</div>

	<div class="listType_1__item">
		<div class="listType_1__item__info">
			<div class="listType_1__item__discount">
	            <p>Экономия</p>
	            <h5>4312 грн</h5>
	        </div>
	    </div>
		<figure class="listType_1__pic">
			<div class="listType_1__img">
				<img src="uploads/your_city-balkon-plastikovyj/slider_02/002.jpg" alt="">
			</div>
			<figcaption class="listType_1__title">Балконный блок, дверь со стеклом и глухое окно без открывания</figcaption>
		</figure>
		<div class="listType_1__footer">
			<p class="asPrice_withoutDiscount">Цена без скидки от <span class="line-through">14372 грн</span></p>
			<div class="asPrice">
				Цена от
				<span class="asPrice__count">10060</span>
				<span class="asPrice__currency">грн</span>
			</div>
			<a class="js-callModal asBtnLink asBtnLink--primary" href="#" title="ЗАЯВКА НА ПОКУПКУ балкона">Заказать</a>
		</div>
	</div>

	<div class="listType_1__item">
		<div class="listType_1__item__info">
			<div class="listType_1__item__discount">
	            <p>Экономия</p>
	            <h5>4312 грн</h5>
	        </div>
	    </div>
		<figure class="listType_1__pic">
			<div class="listType_1__img">
				<img src="uploads/your_city-balkon-plastikovyj/slider_02/003.jpg" alt="">
			</div>
			<figcaption class="listType_1__title">Балконный блок, дверь с панелью и окно из двух частей с открыванием</figcaption>
		</figure>
		<div class="listType_1__footer">
			<p class="asPrice_withoutDiscount">Цена без скидки от <span class="line-through">14372 грн</span></p>
			<div class="asPrice">
				Цена от
				<span class="asPrice__count">10060</span>
				<span class="asPrice__currency">грн</span>
			</div>
			<a class="js-callModal asBtnLink asBtnLink--primary" href="#" title="ЗАЯВКА НА ПОКУПКУ балкона">Заказать</a>
		</div>
	</div>

	<div class="listType_1__item">
		<div class="listType_1__item__info">
			<div class="listType_1__item__discount">
	            <p>Экономия</p>
	            <h5>4312 грн</h5>
	        </div>
	    </div>
		<figure class="listType_1__pic">
			<div class="listType_1__img">
				<img src="uploads/your_city-balkon-plastikovyj/slider_02/004.jpg" alt="">
			</div>
			<figcaption class="listType_1__title">Балконный блок, дверь с панелью и окно из двух частей с открыванием</figcaption>
		</figure>
		<div class="listType_1__footer">
			<p class="asPrice_withoutDiscount">Цена без скидки от <span class="line-through">14372 грн</span></p>
			<div class="asPrice">
				Цена от
				<span class="asPrice__count">10060</span>
				<span class="asPrice__currency">грн</span>
			</div>
			<a class="js-callModal asBtnLink asBtnLink--primary" href="#" title="ЗАЯВКА НА ПОКУПКУ балкона">Заказать</a>
		</div>
	</div>

</div>