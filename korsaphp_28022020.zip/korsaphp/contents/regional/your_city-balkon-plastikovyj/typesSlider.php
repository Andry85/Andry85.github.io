<div class="listType_1">

	<div class="listType_1__item">
		<div class="listType_1__item__info">
			<div class="listType_1__item__discount">
	            <p>Экономия</p>
	            <h5>4312 грн</h5>
	        </div>
	    </div>
		<figure class="listType_1__pic">
			<div class="listType_1__img">
				<img src="uploads/your_city-balkon-plastikovyj/slider_01/001.jpg" alt="">
			</div>
			<figcaption class="listType_1__title">Окно на балкон балконная рама</figcaption>
		</figure>
		<div class="listType_1__footer">
			<p class="asPrice_withoutDiscount">Цена без скидки от <span class="line-through">14372 грн</span></p>
			<div class="asPrice">
				Цена от
				<span class="asPrice__count">10060</span>
				<span class="asPrice__currency">грн</span>
			</div>
			<a class="js-callModal asBtnLink asBtnLink--primary" href="#" title="ЗАЯВКА НА ПОКУПКУ балкона">Заказать</a>
		</div>
	</div>

	<div class="listType_1__item">
		<div class="listType_1__item__info">
			<div class="listType_1__item__discount">
	            <p>Экономия</p>
	            <h5>4134 грн</h5>
	        </div>
	    </div>
		<figure class="listType_1__pic">
			<div class="listType_1__img">
				<img src="uploads/your_city-balkon-plastikovyj/slider_01/002.jpg" alt="">
			</div>
			<figcaption class="listType_1__title">Панорамное остекление балкона</figcaption>
		</figure>
		<div class="listType_1__footer">
			<p class="asPrice_withoutDiscount">Цена без скидки от <span class="line-through">13779 грн</span></p>
			<div class="asPrice">
				Цена от
				<span class="asPrice__count">9645</span>
				<span class="asPrice__currency">грн</span>
			</div>
			<a class="js-callModal asBtnLink asBtnLink--primary" href="#" title="ЗАЯВКА НА ПОКУПКУ балкона">Заказать</a>
		</div>
	</div>

	<div class="listType_1__item">
		<div class="listType_1__item__info">
			<div class="listType_1__item__discount">
	            <p>Экономия</p>
	            <h5>4003 грн</h5>
	        </div>
	    </div>
		<figure class="listType_1__pic">
			<div class="listType_1__img">
				<img src="uploads/your_city-balkon-plastikovyj/slider_01/003.jpg" alt="">
			</div>
			<figcaption class="listType_1__title">Окно на балкон из пяти частей с открыванием</figcaption>
		</figure>
		<div class="listType_1__footer">
			<p class="asPrice_withoutDiscount">Цена без скидки от <span class="line-through">13344 грн</span></p>
			<div class="asPrice">
				Цена от
				<span class="asPrice__count">9341</span>
				<span class="asPrice__currency">грн</span>
			</div>
			<a class="js-callModal asBtnLink asBtnLink--primary" href="#" title="ЗАЯВКА НА ПОКУПКУ балкона">Заказать</a>
		</div>
	</div>

	<div class="listType_1__item">
		<div class="listType_1__item__info">
			<div class="listType_1__item__discount">
	            <p>Экономия</p>
	            <h5>4312 грн</h5>
	        </div>
	    </div>
		<figure class="listType_1__pic">
			<div class="listType_1__img">
				<img src="uploads/your_city-balkon-plastikovyj/slider_01/004.jpg" alt="">
			</div>
			<figcaption class="listType_1__title">Панормное остекление балкона, окна до пола</figcaption>
		</figure>
		<div class="listType_1__footer">
			<p class="asPrice_withoutDiscount">Цена без скидки от <span class="line-through">18372 грн</span></p>
			<div class="asPrice">
				Цена от
				<span class="asPrice__count">14060</span>
				<span class="asPrice__currency">грн</span>
			</div>
			<a class="js-callModal asBtnLink asBtnLink--primary" href="#" title="ЗАЯВКА НА ПОКУПКУ балкона">Заказать</a>
		</div>
	</div>

	<div class="listType_1__item">
		<div class="listType_1__item__info">
			<div class="listType_1__item__discount">
	            <p>Экономия</p>
	            <h5>4312 грн</h5>
	        </div>
	    </div>
		<figure class="listType_1__pic">
			<div class="listType_1__img">
				<img src="uploads/your_city-balkon-plastikovyj/slider_01/005.jpg" alt="">
			</div>
			<figcaption class="listType_1__title">Г-образный балкон Балконная рама из 5 частей</figcaption>
		</figure>
		<div class="listType_1__footer">
			<p class="asPrice_withoutDiscount">Цена без скидки от <span class="line-through">14372 грн</span></p>
			<div class="asPrice">
				Цена от
				<span class="asPrice__count">10060</span>
				<span class="asPrice__currency">грн</span>
			</div>
			<a class="js-callModal asBtnLink asBtnLink--primary" href="#" title="ЗАЯВКА НА ПОКУПКУ балкона">Заказать</a>
		</div>
	</div>

	<div class="listType_1__item">
		<div class="listType_1__item__info">
			<div class="listType_1__item__discount">
	            <p>Экономия</p>
	            <h5>4134 грн</h5>
	        </div>
	    </div>
		<figure class="listType_1__pic">
			<div class="listType_1__img">
				<img src="uploads/your_city-balkon-plastikovyj/slider_01/006.jpg" alt="">
			</div>
			<figcaption class="listType_1__title">П-образный балкон Балконная рама из 6 частей </figcaption>
		</figure>
		<div class="listType_1__footer">
			<p class="asPrice_withoutDiscount">Цена без скидки от <span class="line-through">13779 грн</span></p>
			<div class="asPrice">
				Цена от
				<span class="asPrice__count">9645</span>
				<span class="asPrice__currency">грн</span>
			</div>
			<a class="js-callModal asBtnLink asBtnLink--primary" href="#" title="ЗАЯВКА НА ПОКУПКУ балкона">Заказать</a>
		</div>
	</div>

	<div class="listType_1__item">
		<div class="listType_1__item__info">
			<div class="listType_1__item__discount">
	            <p>Экономия</p>
	            <h5>4003 грн</h5>
	        </div>
	    </div>
		<figure class="listType_1__pic">
			<div class="listType_1__img">
				<img src="uploads/your_city-balkon-plastikovyj/slider_01/007.jpg" alt="">
			</div>
			<figcaption class="listType_1__title">Полукруглый балкон Балконная рама из 5 частей</figcaption>
		</figure>
		<div class="listType_1__footer">
			<p class="asPrice_withoutDiscount">Цена без скидки от <span class="line-through">13344 грн</span></p>
			<div class="asPrice">
				Цена от
				<span class="asPrice__count">9341</span>
				<span class="asPrice__currency">грн</span>
			</div>
			<a class="js-callModal asBtnLink asBtnLink--primary" href="#" title="ЗАЯВКА НА ПОКУПКУ балкона">Заказать</a>
		</div>
	</div>

	<div class="listType_1__item">
		<div class="listType_1__item__info">
			<div class="listType_1__item__discount">
	            <p>Экономия</p>
	            <h5>4003 грн</h5>
	        </div>
	    </div>
		<figure class="listType_1__pic">
			<div class="listType_1__img">
				<img src="uploads/your_city-balkon-plastikovyj/slider_01/008.jpg" alt="">
			</div>
			<figcaption class="listType_1__title">Г-образный балкон Балконная рама из 4 частей</figcaption>
		</figure>
		<div class="listType_1__footer">
			<p class="asPrice_withoutDiscount">Цена без скидки от <span class="line-through">18372 грн</span></p>
			<div class="asPrice">
				Цена от
				<span class="asPrice__count">14060</span>
				<span class="asPrice__currency">грн</span>
			</div>
			<a class="js-callModal asBtnLink asBtnLink--primary" href="#" title="ЗАЯВКА НА ПОКУПКУ балкона">Заказать</a>
		</div>
	</div>



	

	

</div>