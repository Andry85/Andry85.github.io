<div class="listType_1 listType_1--onlyPhoto">

	<div class="listType_1__item">
		<a class="listType_1__link" href="uploads/your_city-dveri-mezhkomnatnye-derevynie/slider_2/001.png" title="" data-fancybox="slider_2">
			<figure class="listType_1__pic">
				<div class="listType_1__img">
					<img src="uploads/your_city-dveri-mezhkomnatnye-derevynie/slider_2/001.png" alt="">
				</div>
			</figure>
		</a>
	</div>
	<div class="listType_1__item">
		<a class="listType_1__link" href="uploads/your_city-dveri-mezhkomnatnye-derevynie/slider_2/002.png" title="" data-fancybox="slider_2">
			<figure class="listType_1__pic">
				<div class="listType_1__img">
					<img src="uploads/your_city-dveri-mezhkomnatnye-derevynie/slider_2/002.png" alt="">
				</div>
			</figure>
		</a>
	</div>
	<div class="listType_1__item">
		<a class="listType_1__link" href="uploads/your_city-dveri-mezhkomnatnye-derevynie/slider_2/003.png" title="" data-fancybox="slider_2">
			<figure class="listType_1__pic">
				<div class="listType_1__img">
					<img src="uploads/your_city-dveri-mezhkomnatnye-derevynie/slider_2/003.png" alt="">
				</div>
			</figure>
		</a>
	</div>
	<div class="listType_1__item">
		<a class="listType_1__link" href="uploads/your_city-dveri-mezhkomnatnye-derevynie/slider_2/004.png" title="" data-fancybox="slider_2">
			<figure class="listType_1__pic">
				<div class="listType_1__img">
					<img src="uploads/your_city-dveri-mezhkomnatnye-derevynie/slider_2/004.png" alt="">
				</div>
			</figure>
		</a>
	</div>
	<div class="listType_1__item">
		<a class="listType_1__link" href="uploads/your_city-dveri-mezhkomnatnye-derevynie/slider_2/005.png" title="" data-fancybox="slider_2">
			<figure class="listType_1__pic">
				<div class="listType_1__img">
					<img src="uploads/your_city-dveri-mezhkomnatnye-derevynie/slider_2/005.png" alt="">
				</div>
			</figure>
		</a>
	</div>
	<div class="listType_1__item">
		<a class="listType_1__link" href="uploads/your_city-dveri-mezhkomnatnye-derevynie/slider_2/006.png" title="" data-fancybox="slider_2">
			<figure class="listType_1__pic">
				<div class="listType_1__img">
					<img src="uploads/your_city-dveri-mezhkomnatnye-derevynie/slider_2/006.png" alt="">
				</div>
			</figure>
		</a>
	</div>
	<div class="listType_1__item">
		<a class="listType_1__link" href="uploads/your_city-dveri-mezhkomnatnye-derevynie/slider_2/007.png" title="" data-fancybox="slider_2">
			<figure class="listType_1__pic">
				<div class="listType_1__img">
					<img src="uploads/your_city-dveri-mezhkomnatnye-derevynie/slider_2/007.png" alt="">
				</div>
			</figure>
		</a>
	</div>
	<div class="listType_1__item">
		<a class="listType_1__link" href="uploads/your_city-dveri-mezhkomnatnye-derevynie/slider_2/008.png" title="" data-fancybox="slider_2">
			<figure class="listType_1__pic">
				<div class="listType_1__img">
					<img src="uploads/your_city-dveri-mezhkomnatnye-derevynie/slider_2/008.png" alt="">
				</div>
			</figure>
		</a>
	</div>


</div>