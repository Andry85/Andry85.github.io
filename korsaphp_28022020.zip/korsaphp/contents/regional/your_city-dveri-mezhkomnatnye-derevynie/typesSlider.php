<div class="listType_1 listType_1--onlyPhoto">

	<div class="listType_1__item">
		<a class="listType_1__link" href="uploads/your_city-dveri-mezhkomnatnye-derevynie/slider_1/001.png" title="" data-fancybox="slider_1">
			<figure class="listType_1__pic">
				<div class="listType_1__img">
					<img src="uploads/your_city-dveri-mezhkomnatnye-derevynie/slider_1/001.png" alt="">
				</div>
			</figure>
		</a>
	</div>
	<div class="listType_1__item">
		<a class="listType_1__link" href="uploads/your_city-dveri-mezhkomnatnye-derevynie/slider_1/002.png" title="" data-fancybox="slider_1">
			<figure class="listType_1__pic">
				<div class="listType_1__img">
					<img src="uploads/your_city-dveri-mezhkomnatnye-derevynie/slider_1/002.png" alt="">
				</div>
			</figure>
		</a>
	</div>
	<div class="listType_1__item">
		<a class="listType_1__link" href="uploads/your_city-dveri-mezhkomnatnye-derevynie/slider_1/003.png" title="" data-fancybox="slider_1">
			<figure class="listType_1__pic">
				<div class="listType_1__img">
					<img src="uploads/your_city-dveri-mezhkomnatnye-derevynie/slider_1/003.png" alt="">
				</div>
			</figure>
		</a>
	</div>
	<div class="listType_1__item">
		<a class="listType_1__link" href="uploads/your_city-dveri-mezhkomnatnye-derevynie/slider_1/004.png" title="" data-fancybox="slider_1">
			<figure class="listType_1__pic">
				<div class="listType_1__img">
					<img src="uploads/your_city-dveri-mezhkomnatnye-derevynie/slider_1/004.png" alt="">
				</div>
			</figure>
		</a>
	</div>
	<div class="listType_1__item">
		<a class="listType_1__link" href="uploads/your_city-dveri-mezhkomnatnye-derevynie/slider_1/005.png" title="" data-fancybox="slider_1">
			<figure class="listType_1__pic">
				<div class="listType_1__img">
					<img src="uploads/your_city-dveri-mezhkomnatnye-derevynie/slider_1/005.png" alt="">
				</div>
			</figure>
		</a>
	</div>
	<div class="listType_1__item">
		<a class="listType_1__link" href="uploads/your_city-dveri-mezhkomnatnye-derevynie/slider_1/006.png" title="" data-fancybox="slider_1">
			<figure class="listType_1__pic">
				<div class="listType_1__img">
					<img src="uploads/your_city-dveri-mezhkomnatnye-derevynie/slider_1/006.png" alt="">
				</div>
			</figure>
		</a>
	</div>
	<div class="listType_1__item">
		<a class="listType_1__link" href="uploads/your_city-dveri-mezhkomnatnye-derevynie/slider_1/007.png" title="" data-fancybox="slider_1">
			<figure class="listType_1__pic">
				<div class="listType_1__img">
					<img src="uploads/your_city-dveri-mezhkomnatnye-derevynie/slider_1/007.png" alt="">
				</div>
			</figure>
		</a>
	</div>
	<div class="listType_1__item">
		<a class="listType_1__link" href="uploads/your_city-dveri-mezhkomnatnye-derevynie/slider_1/008.png" title="" data-fancybox="slider_1">
			<figure class="listType_1__pic">
				<div class="listType_1__img">
					<img src="uploads/your_city-dveri-mezhkomnatnye-derevynie/slider_1/008.png" alt="">
				</div>
			</figure>
		</a>
	</div>


</div>